#!/usr/local/apps/python/python-controlled/bin/python -tt
""" 
TODO: right now QC"s repoted in log, make more sophisticated
"""
import logging
logging.basicConfig(level=logging.DEBUG, format='%(asctime)s\t[%(levelname)s]\t%(message)s', datefmt='%d-%b-%y %H:%M:%S')
log = logging.getLogger(__name__)

import datetime
import numpy as np
import pandas as pd
from pandas.util.testing import assert_frame_equal # <-- for testing dataframes
import re
#-----------------------------------------------------------------------------#

class DataFrameDataChecks:
    """This is a foundational class which should not depend on any other modules
    in this project. (*** expect maybe for datachecks?) It should be unaware of
    Pipeline objects.

    This class provides methods which manipulate a pandas dataframe.
    This class is instantiated with a dataframe to manipulate.
    All other information used in manipulations comes from parameters to these methods:
    either scalars, lists, or other pandas dataframe objects.
    """

    def __init__(self, data_frame_to_manipulate):
        self.data_frame = data_frame_to_manipulate





    # -------------  Data Frame Structure checks  -------------------------- #
    # TODO: break into another file?



    def is_field_present(self, field_name):
        """ Is the field present in the DataFrame?

         TODO: this type of check can not be with the qc containter.

        Args:
            field_name (str): name of field to check

        Returns:
            True is check passes for all values in field_name, else False.
        """
        err_msg = 'Data Structure Check Fail: field {} is missing.'.format(field_name)
        ok_msg = 'Data Structure Check OK: field {} is present.'.format(field_name)
        
        check_result = True

        if field_name not in self.data_frame:
            check_result = False
            log.error(err_msg)
        else:
            log.info(ok_msg)

        return check_result

    def are_all_fields_present(self, field_list, require_exact_match = True):
        # TODO document and unit test

        # TODO: info, error logging messages

        if not len(field_list) >= 1:
            return False
        if require_exact_match:
            if not len(field_list) == len(self.data_frame.columns):
                return False

        all_fields_found = True

        # unordered check
        for field in field_list:
            field_found = self.is_field_present(field)
            if not field_found:
                all_fields_found = False

        return all_fields_found




    # -------------  Data Frame Content checks  -------------------------- #





    def are_field_values_not_blank(self, field_name):
        """ Are all values in the field not blank? blank == np.nan or None

        Args:
            field_name (str): name of field to check

        Returns:
            True is check passes for all values in field_name, else False.

        Raises:
            KeyError: if field_name is not in DataFrame.
        """
        if field_name not in self.data_frame:
            raise KeyError

        err_msg = 'Data Value Check FAIL: field \'{}\' must not be blank.'
        ok_msg = 'Data Value Check OK: field \'{}\' was never blank.'

        check_result = True

        truth_series = self.data_frame[field_name].isnull()
        for index, is_null in truth_series.iteritems():
            if is_null:
                check_result = False

        if not check_result:
            log.error(err_msg.format(field_name))
        else:
            log.info(ok_msg.format(field_name))

        return check_result


    def does_field_A_have_content_if_field_B_contains_trigger_values(self, field_name_A, field_name_B, field_B_trigger_values_set):
        """

        !! NOTE: <blank> is defined by agreement as np.nan or None


        We often want to make sure that a field has content, but only when another field contains specified values.

        for example:

            field_name_A: summary_type

            field_name_B: is_summary

            field_name_B_trigger_values: ['true', '1']


            A                |  B           |    row-by-row result
            ------------------------------------------------------
            <blank>          |  <blank>     |       True: field B does not contain the specified value; check not applied
            <blank>          |  'false'     |       True: field B does not contain the specified value; check not applied
            <blank>          |  'true'      |       False: field B _does_ contain a trigger value; check _is applied_ and A is blank
            'inter-assay'    |  <blank>     |       True: field B does not contain the specified value; check not applied
            'inter-assay'    |  'false'     |       True: field B does not contain the specified value; check not applied
            'inter-assay'    |  'true'      |       True: field B _does_ contain a trigger value; check _is applied_ and A _is not_ blank


        table-wise result: 
            
            logical AND applied over all row-by-row results:
            ------------------------------------------------
                False: there is at least one False row result


        Returns:
            True if all table-wise results are true; False otherwise

        Raises:
            KeyError: if field_names are not in DataFrame.

        Logs:
            If Return is True
                INFO: field A had values for all rows in which field B contained specified values
                INFO:       <list of field B specified values>

            If Return is False
                WARNING: field A had NN blank rows when field B contained specified values
                WARNING:       <list of field B specified values>
        """
        missing_field_error_message = "data check requested involving field {}, but no such field exists in data frame"
        
        for field_name in [field_name_A, field_name_B]:
            if field_name not in self.data_frame:
                log.error(missing_field_error_message.format(field_name))
                raise KeyError('{} missing from data.'.format(field_name))



        cummulative_result = True

        field_A_blank_truth_series = self.data_frame[field_name_A].isnull()
        field_B_trigger_truth_series = self.data_frame[field_name_B].isin(field_B_trigger_values_set)

        num_bad_rows = 0

        for blank_status, test_triggered in zip(field_A_blank_truth_series, field_B_trigger_truth_series):
            if test_triggered and (blank_status == True):
                cummulative_result = False
                num_bad_rows = num_bad_rows + 1


       
        if cummulative_result == False:
            err_msg = 'Data Value Check FAIL: {} bad rows found where field {} was blank when field {} contains a value from:'
            err_msg = err_msg + "\n\t"
            err_msg = err_msg + ', '.join(field_B_trigger_values_set)
            log.warning(err_msg.format(num_bad_rows, field_name_A, field_name_B, field_B_trigger_values_set))
        else:
            info_msg = 'Data Value Check OK: field {} was never blank when when field {} contained '
            if len(field_B_trigger_values_set) ==  1:
                info_msg = info_msg + "the value {}".format(field_B_trigger_values_set[0])
            else:
                info_msg = info_msg + "one of the values in the set " + ', '.join(field_B_trigger_values_set) 

            log.info(info_msg.format(field_name_A, field_name_B, field_B_trigger_values_set))



        return cummulative_result



    def does_field_A_have_content_if_field_B_contains_any_values(self, field_name_A, field_name_B):
        """

        !! NOTE: <blank> is defined by agreement as np.nan or None


        We often want to make sure that a field has content, but only when another field contains any values.

        for example:

            field_name_A: summary_type

            field_name_B: is_summary



            A                |  B           |    row-by-row result
            ------------------------------------------------------
            <blank>          |  <blank>     |       True: field B is blank; check not applied
            <blank>          |  'true'      |       False: field B _does_ contain any value; check _is applied_ and A _is_ blank
            'inter-assay'    |  <blank>     |       True: field B is blank; check not applied
            'inter-assay'    |  'true'      |       True: field B _does_ contain any value; check _is applied_ and A _is not_ blank


        table-wise result: 
            
            logical AND applied over all row-by-row results:
            ------------------------------------------------
                False: there is at least one False row result


        Returns:
            True if all table-wise results are true; False otherwise

        Raises:
            KeyError: if field_names are not in DataFrame.

        Logs:
            If Return is True
                INFO: field A had values for all rows in which field B contained values
                INFO:       <list of field B specified values>

            If Return is False
                WARNING: field A had NN blank rows when field B contained values
                WARNING:       <list of field B specified values>
        """
        missing_field_error_message = "data check requested involving field {}, but no such field exists in data frame"
        
        for field_name in [field_name_A, field_name_B]:
            if field_name not in self.data_frame:
                log.error(missing_field_error_message.format(field_name))
                raise KeyError('{} missing from data.'.format(field_name))



        cummulative_result = True

        field_A_is_blank_truth_series = self.data_frame[field_name_A].isnull()
        field_B_has_content_truth_series = self.data_frame[field_name_B].notnull()

        num_bad_rows = 0

        for is_field_A_blank, does_field_B_have_content in zip(field_A_is_blank_truth_series, field_B_has_content_truth_series):
            if does_field_B_have_content and (is_field_A_blank == True):
                cummulative_result = False
                num_bad_rows = num_bad_rows + 1


       
        if cummulative_result == False:
            err_msg = 'Data Value Check FAIL: {} bad rows found where field {} was blank when field {} had content'
            log.warning(err_msg.format(num_bad_rows, field_name_A, field_name_B))
        else:
            info_msg = 'Data Value Check OK: field {} was never blank when when field {} had content'
            log.info(info_msg.format(field_name_A, field_name_B))



        return cummulative_result




    def is_virusid_field_conditionally_not_blank(self):
        """ ldxnab001 specific method. TODO: generalize

        Returns:
            True if check passes, else False

        Raises:
            KeyError: if field_name is not in DataFrame.
        """
        check_field = 'virusid'
        condition_field = 'virusnameother'

        if check_field not in self.data_frame:
            raise KeyError('{} missing from data.'.format(check_field))
        if condition_field not in self.data_frame:
            raise KeyError('{} missing from data.'.format(condition_field))

        err_msg = 'Data Value Check Fail: field virusid must not be blank when there is a non-blank value in field virusnameother.'
        check_result = True

        check_field_truth_series = self.data_frame[check_field].isnull()
        condition_field_truth_series = self.data_frame[condition_field].isnull()

        for check, condition in zip(check_field_truth_series, condition_field_truth_series):
            if check and not condition:
                check_result = False

        if not check_result:
            log.error(err_msg)                
        return check_result

    def are_all_rows_primary_key_unique(self, primary_key_list):
        """ Check that DataFrame contains unique rows as definied by the primary_key_list of column name(s).

        # TODO rename param to "tuple" or "set"

        Args:
            primary_key_list (tuple): set of field names that identify a unique row.
        
        Raises:
            KeyError: if any value in primary_key_list is not a field in DataFrame.
        """

        # check if any value in primary_key is not a field in DataFrame
        for field_name in primary_key_list:
            if field_name not in self.data_frame:
                raise KeyError

        subset = primary_key_list
        keep = False # Mark all duplicates as True.
        duplicated_check_list = self.data_frame.duplicated(subset = subset, keep = keep)
        
        found_dups = False
        for i, check_value in duplicated_check_list.iteritems():
            if check_value == True:
                log.warn("found duplicate data row at index {}".format(i))
                found_dups = True
        
        all_rows_unique = not found_dups


        if all_rows_unique:
            log.info('Data Value Check OK: all rows were unique, based on specified primary keys')
        else:
            log.warning('Data Value Check FAIL: duplicate rows were found, based on specified primary keys')
        return all_rows_unique


    # TODO
    # unit tests!!! NT reivew tests written by JL
    # docstring
    # check that field exists
    def are_field_contents_in_list(self, field_name, acceptable_value_list, ignore_blank_values = False):
        """
        Args:
            ignore_blank_values
                By default, this check will be applied to all rows. However, if a blank-value check is done elsewhere,
                this argument enables the developer to limit this check to non-blank values.
        """

        # check field_name, row by row, and make sure the value is in acceptable_value_list

        # for now, report the number of problem rows


        # TODO: find a more elegant way to do this?
        original_acceptable_value_list = list(acceptable_value_list) # deep copy
        if ignore_blank_values:
            acceptable_value_list.append(None)
            acceptable_value_list.append(np.nan)
            acceptable_value_list.append('') # TODO investiage why we get blank strings here


        df_with_bad_rows = self.data_frame[ ~self.data_frame[field_name].isin(acceptable_value_list)]
        num_bad_rows = df_with_bad_rows.shape[0]

        # TODO: talk about blanks
        error_message = 'Data Value Check FAIL: '
        ok_message =  'Data Value Check OK: non-blank content for field {} matched the acceptable value list.'.format(field_name)

        if num_bad_rows > 0:

            error_message = error_message + "field {} had {} rows that did not match the acceptable value list;".format(field_name, num_bad_rows)
            error_message = error_message + "Acceptable values for {} are: ".format(field_name)

            error_message = error_message + "{}".format(', '.join(original_acceptable_value_list))

            if ignore_blank_values:
                error_message = error_message + ", as well as blank values"

            error_message = error_message + ". Top unacceptable values were (listing at most 10):"
            # df[ ~df['ptid'].isin(['HT92','EC23']) ]['ptid'].value_counts().sort_values(ascending=False)

            df = self.data_frame.copy(deep=True)

            group_count = 0
            for bad_cell_value, observed_count in df[ ~df[field_name].isin(acceptable_value_list) ][field_name].value_counts().sort_values(ascending=False).iteritems():
                error_message = error_message + "\"{}\" was observed {} times; ".format(bad_cell_value, observed_count)
                group_count = group_count + 1
                if group_count >= 10:
                    break



            log.warning(error_message)
            return False
        else:
            log.info(ok_message)
            return True



    # TODO
    # unit tests!!! NT review tests written by JL
    # docstring
    # check that field exists
    def is_field_numeric(self, field_name, ignore_blank_values = False):
        """
        Args:
            ignore_blank_values
                By default, this check will be applied to all rows. However, if a blank-value check is done elsewhere,
                this argument enables the developer to limit this check to non-blank values.
        """


        num_bad_rows = 0
        for index, row in self.data_frame.iterrows():
            if ignore_blank_values:
                if row[field_name] in [None, np.nan, '']: # TODO why are '' coming in?
                    # skip this row
                    continue
            if not self.is_string_numeric(row[field_name]):
                num_bad_rows = num_bad_rows + 1

        row_type = ''
        if ignore_blank_values:
            row_type = 'non-blank rows'
        else:
            row_type = 'rows'
        

        if num_bad_rows > 0:
            log.warning("Data Value Check FAIL: field {} had {} {} that were not numeric".format(field_name, num_bad_rows, row_type))
            return False
        else:
            log.info("Data Value Check OK: all {} for field {} were numeric".format(row_type, field_name))
            return True



    def is_numeric_field_value_in_a_range_inclusive(self, field_name, min_value, max_value, ignore_non_numeric = False, ignore_blank_values = False):
        """
        Args:
            ignore_blank_values
                By default, this check will be applied to all rows. However, if a blank-value check is done elsewhere,
                this argument enables the developer to limit this check to non-blank values.
        """


        num_bad_rows = 0
        for index, row in self.data_frame.iterrows():

            cur_value_string = row[field_name]
            if ignore_blank_values:
                if cur_value_string in [None, np.nan, '']: # TODO why are '' coming in?
                    # skip this row
                    continue

            if not self.is_string_numeric(cur_value_string):
                # not numeric
                if not ignore_non_numeric:
                    num_bad_rows = num_bad_rows + 1

                continue

            if ((cur_value_string < min_value) or (cur_value_string > max_value)):
                num_bad_rows = num_bad_rows + 1


        row_type = ''
        if ignore_blank_values:
            row_type = 'non-blank rows'
        else:
            row_type = 'rows'
        

        if num_bad_rows > 0:
            log.warning("Data Value Check FAIL: field {} had {} {} with numeric values that were not within the inclusive range {} to {}".format(field_name, num_bad_rows, row_type, min_value, max_value))
            return False
        else:
            log.info("Data Value Check OK: all {} with numeric values for field {} were within the inclusive range {} to {}".format(row_type, field_name, min_value, max_value))
            return True



    def is_numeric_field_value_gt_eq(self, field_name, min_value, ignore_non_numeric = False, ignore_blank_values = False):
        """
        Args:
            ignore_blank_values
                By default, this check will be applied to all rows. However, if a blank-value check is done elsewhere,
                this argument enables the developer to limit this check to non-blank values.
        """


        num_bad_rows = 0
        for index, row in self.data_frame.iterrows():

            cur_value_string = row[field_name]
            if ignore_blank_values:
                if cur_value_string in [None, np.nan, '']: # TODO why are '' coming in?
                    # skip this row
                    continue

            if not self.is_string_numeric(cur_value_string):
                # not numeric
                if not ignore_non_numeric:
                    num_bad_rows = num_bad_rows + 1

                continue

            if (cur_value_string < min_value):
                num_bad_rows = num_bad_rows + 1


        row_type = ''
        if ignore_blank_values:
            row_type = 'non-blank rows'
        else:
            row_type = 'rows'
        

        if num_bad_rows > 0:
            log.warning("Data Value Check FAIL: field {} had {} {} with numeric values that were less than {}".format(field_name, num_bad_rows, row_type, min_value))
            return False
        else:
            log.info("Data Value Check OK: all {} with numeric values for field {} were greater or equal to {}".format(row_type, field_name, min_value))
            return True





    def are_field_date_values_on_or_before_a_given_date(self, field_name, comparison_date_string, date_format, ignore_blank_values = False):
        """
        # TODO:
        document
        arg checks
        logging
        unit tests
        try/except
        """

        
        comparison_datetime_value = datetime.datetime.strptime(comparison_date_string, date_format)

        result = True
        num_bad_rows = 0

        for index, row in self.data_frame.iterrows():
            field_value = row[field_name]
            
            if ignore_blank_values:
                if field_value in [None, np.nan, '']:
                    continue

            field_datetime_value = datetime.datetime.strptime(field_value, date_format)
            
            if field_datetime_value > comparison_datetime_value:
                result = False
                num_bad_rows = num_bad_rows + 1


        if result == False:
            log.warning("Data Value Check FAIL: field {} had {} non-blank rows with a date greater than {}".format(field_name, num_bad_rows, comparison_date_string))
        else:
            log.info("Data Value Check OK: all non-blank rows for field {} had a date less than or equal to {}".format(field_name, comparison_date_string))
 
        return result





    # ------------- helper methods - TODO organize ------------ #





    def is_string_numeric(self, test_string):
        # unit tests!!! NT review tests written by JL
        # !!!! JL deleted '/' from start and end of regular expression, NT please confirm correct action
        int_regex = r'^[-+]?\d+$'
        float_regex = r'^[-+]?\d*\.?\d+$'
        sci_regex = r'^([-+]?\d*\.?\d+)(?:[eE]([-+]?\d+))?$'


        parse_match = re.search(int_regex, test_string)
        if parse_match:
            return True

        parse_match = re.search(float_regex, test_string)
        if parse_match:
            return True

        parse_match = re.search(sci_regex, test_string)
        if parse_match:
            return True

        return False

