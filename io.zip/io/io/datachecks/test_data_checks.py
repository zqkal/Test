#!/usr/local/apps/python/python-controlled/bin/python -tt

#-----------------------------------------------------------------------------#

import pandas as pd
import numpy as np
import pytest

from data_checks import DataFrameDataChecks

#-----------------------------------------------------------------------------#

class TestIsFieldPresent:
    
    def test_field_is_not_missing(self):
        df = DataFrameDataChecks(pd.DataFrame({
            'network': ['hvtn'], 
            'protocol': [116]}))
        result = df.is_field_present('network')
        assert result == True

    def test_field_is_missing(self):
        df = DataFrameDataChecks(pd.DataFrame({
            'network': ['hvtn'],
            'protocol': [116]}))
        result = df.is_field_present('ptid')
        assert result == False


class TestAreFieldValuesNotBlank:

    def test_raise_key_error_for_missing_field(self):
        df = DataFrameDataChecks(pd.DataFrame())
        with pytest.raises(KeyError):
            df.are_field_values_not_blank('ptid')

    def test_detects_nan(self):
        df = DataFrameDataChecks(pd.DataFrame({'network': ['hvtn', np.nan]}))
        result = df.are_field_values_not_blank('network')
        assert result == False

    def test_detects_none(self):
        df = DataFrameDataChecks(pd.DataFrame({'network': ['hvtn', None]}))
        result = df.are_field_values_not_blank('network')
        assert result == False

    def test_no_missing_fields(self):
        """ DEVEL NOTE: method only should counsider np.nan to be a blank value. """
        df = DataFrameDataChecks(pd.DataFrame({'network': ['hvtn', '']}))
        result = df.are_field_values_not_blank('network')
        assert result == True



class TestDoesFieldAHaveContentIfFieldBContainsTriggerValues:

    def test_raise_key_error_for_missing_field_A(self):
        df = pd.DataFrame({
                'summary_type': [None, np.nan, None, 'inter-assay', 'inter-assay', 'inter-assay'],
                'is_summary': [None, 'false', 'true', np.nan, 'false', 'true']
            })
        checker = DataFrameDataChecks(df)
        with pytest.raises(KeyError):
            checker.does_field_A_have_content_if_field_B_contains_trigger_values('specrole', 'is_summary', ['1', 'true'])

    def test_raise_key_error_for_missing_field_B(self):
        df = pd.DataFrame({
                'summary_type': [None, np.nan, None, 'inter-assay', 'inter-assay', 'inter-assay'],
                'is_summary': [None, 'false', 'true', np.nan, 'false', 'true']
            })
        checker = DataFrameDataChecks(df)
        with pytest.raises(KeyError):
            checker.does_field_A_have_content_if_field_B_contains_trigger_values('summary_type', 'specrole', ['1', 'true'])

    def test_field_A_blank_and_condition_met(self):
        df = pd.DataFrame({
                'summary_type': [None, np.nan, None, 'inter-assay', 'inter-assay', 'inter-assay'],
                'is_summary': [None, 'false', 'true', np.nan, 'false', 'true']
            })
        trigger_values = ['1', 'true']
        checker = DataFrameDataChecks(df)
        result = checker.does_field_A_have_content_if_field_B_contains_trigger_values('summary_type', 'is_summary', trigger_values)
        assert result == False

    def test_field_A_blank_and_condition_not_met(self):
        df = pd.DataFrame({
                'summary_type': [None, np.nan, None, 'inter-assay', 'inter-assay', 'inter-assay'],
                'is_summary': [None, 'false', 'false', np.nan, 'false', None]
            })
        trigger_values = ['1', 'true']
        checker = DataFrameDataChecks(df)
        result = checker.does_field_A_have_content_if_field_B_contains_trigger_values('summary_type', 'is_summary', trigger_values)
        assert result == True

    def test_field_A_not_blank_and_condition_met(self):
        df = pd.DataFrame({
                'summary_type': [None, np.nan, None, 'inter-assay', 'inter-assay', 'inter-assay'],
                'is_summary': [None, 'false', 'false', np.nan, 'true', None]
            })
        trigger_values = ['1', 'true']
        checker = DataFrameDataChecks(df)
        result = checker.does_field_A_have_content_if_field_B_contains_trigger_values('summary_type', 'is_summary', trigger_values)
        assert result == True


class TestDoesFieldAHaveContentIfFieldBHasContent:

    def test_raise_key_error_for_missing_field_A(self):
        df = pd.DataFrame({
                'summary_type': [None, np.nan, None, 'inter-assay', 'inter-assay', 'inter-assay'],
                'is_summary': [None, 'false', 'true', np.nan, 'false', 'true']
            })
        checker = DataFrameDataChecks(df)
        with pytest.raises(KeyError):
            checker.does_field_A_have_content_if_field_B_contains_any_values('specrole', 'is_summary')

    def test_raise_key_error_for_missing_field_B(self):
        df = pd.DataFrame({
                'summary_type': [None, np.nan, None, 'inter-assay', 'inter-assay', 'inter-assay'],
                'is_summary': [None, 'false', 'true', np.nan, 'false', 'true']
            })
        checker = DataFrameDataChecks(df)
        with pytest.raises(KeyError):
            checker.does_field_A_have_content_if_field_B_contains_any_values('summary_type', 'specrole')

    def test_field_A_blank_and_field_B_blank(self):
        df = pd.DataFrame({
                'summary_type': [None, np.nan, None, 'inter-assay', 'inter-assay', 'inter-assay'],
                'is_summary':   [None, np.nan, None, np.nan, 'false', 'true']
            })
        checker = DataFrameDataChecks(df)
        result = checker.does_field_A_have_content_if_field_B_contains_any_values('summary_type', 'is_summary')
        assert result == True

    def test_field_A_blank_and_field_B_not_blank(self):
        df = pd.DataFrame({
                'summary_type': [None, np.nan, None, 'inter-assay', 'inter-assay', 'inter-assay'],
                'is_summary':   ['true', 'false', 'false', 'true', 'false', 'false']
            })
        trigger_values = ['1', 'true']
        checker = DataFrameDataChecks(df)
        result = checker.does_field_A_have_content_if_field_B_contains_any_values('summary_type', 'is_summary')
        assert result == False

    def test_field_A_not_blank_and_field_B_blank(self):
        df = pd.DataFrame({
                'summary_type': ['true', 'false', 'false', 'inter-assay', 'inter-assay', 'inter-assay'],
                'is_summary':   [None, np.nan, None, np.nan, 'false', 'true']
            })
        checker = DataFrameDataChecks(df)
        result = checker.does_field_A_have_content_if_field_B_contains_any_values('summary_type', 'is_summary')
        assert result == True

    def test_field_A_not_blank_and_field_B_not_blank(self):
        df = pd.DataFrame({
                'summary_type': ['true', 'false', 'false', 'inter-assay', 'inter-assay', 'inter-assay'],
                'is_summary':   ['true', 'false', 'false', 'true', 'false', 'false']
            })
        trigger_values = ['1', 'true']
        checker = DataFrameDataChecks(df)
        result = checker.does_field_A_have_content_if_field_B_contains_any_values('summary_type', 'is_summary')
        assert result == True

class TestIsVirusidFieldConditionallyNotBlank:

    def test_raise_key_error_for_missing_virusid_field(self):
        df = DataFrameDataChecks(pd.DataFrame({
            'virusnameother': ['whiskers', 'bob']}))
        with pytest.raises(KeyError):
            df.is_virusid_field_conditionally_not_blank()

    def test_raise_key_error_for_missing_virusnameother_field(self):
        df = DataFrameDataChecks(pd.DataFrame({
            'virusid': ['whiskers', 'bob']}))
        with pytest.raises(KeyError):
            df.is_virusid_field_conditionally_not_blank()

    def test_virusid_blank_and_condition_met(self):
        df = DataFrameDataChecks(pd.DataFrame({
            'virusid': ['id', np.nan, np.nan],
            'virusnameother': ['whiskers', np.nan, 'bob']}))
        result = df.is_virusid_field_conditionally_not_blank()
        assert result == False

    def test_virusid_blank_and_condition_not_met(self):
        df = DataFrameDataChecks(pd.DataFrame({
            'virusid': ['id', np.nan],
            'virusnameother': ['whiskers', np.nan]}))
        result = df.is_virusid_field_conditionally_not_blank()
        assert result == True

    def test_virusid_not_blank_and_condition_met(self):
        df = DataFrameDataChecks(pd.DataFrame({
            'virusid': ['id1', 'id2'],
            'virusnameother': ['whiskers', np.nan]}))
        result = df.is_virusid_field_conditionally_not_blank()
        assert result == True


class TestAreAllRowsPrimaryKeyUnique:

    # TODO: test KeyError on bad args for key list
    def test_bad_key_field_list(self):
        df = pd.DataFrame({
            'ptid': ['IC47', 'HT92', 'RGw11', 'EC23'], 
            'visitno': ['Week', 'Day', 'Week', 'Weed'],
            'visit_modifier': ['6', '0', '26', '6']
            })
        checker = DataFrameDataChecks(df)

        key_fields = ['ptid', 'XvisitnoX', 'visit_modifier']

        with pytest.raises(KeyError):
            checker.are_all_rows_primary_key_unique(key_fields)

    def test_unique_rows_ok(self):
        df = pd.DataFrame({
            'ptid': ['IC47', 'HT92', 'RGw11', 'EC23'], 
            'visitno': ['Week', 'Day', 'Week', 'Week'],
            'visit_modifier': ['6', '0', '26', '6']
            })
        checker = DataFrameDataChecks(df)

        key_fields = ['ptid', 'visitno', 'visit_modifier']

        assert checker.are_all_rows_primary_key_unique(key_fields)

    def test_detect_duplicate_rows(self):

        df = pd.DataFrame({
            'ptid': ['IC47', 'HT92', 'RGw11', 'EC23'], 
            'visitno': ['Week', 'Day', 'Week', 'Week'],
            'visit_modifier': ['6', '0', '26', '6']
            })
        checker = DataFrameDataChecks(df)

        key_fields = ['visitno', 'visit_modifier']

        assert checker.are_all_rows_primary_key_unique(key_fields) == False

class TestAreAllFieldsPresent():
    
    @pytest.fixture
    def checker(self):
        df = pd.DataFrame({
            'ptid': ['IC47', 'HT92', 'RGw11', 'EC23'],
            'visitno': ['Week', 'Day', 'Week', 'Week'],
            'visit_modifier': ['6', '0', '26', '6']
            })
        chkr = DataFrameDataChecks(df)
        return chkr

    def test_returns_true_if_same_number_of_fields(self, checker):
        field_list = ['ptid', 'visitno', 'visit_modifier']
        response = checker.are_all_fields_present(field_list)
        assert response

    def test_returns_false_if_fewer_fields_provided(self, checker):
        field_list = ['ptid', 'visit_modifier']
        response = checker.are_all_fields_present(field_list)
        assert response == False

    def test_returns_false_if_more_fields_present(self, checker):
        field_list = ['ptid', 'visitno', 'visit_modifier', 'fizzbuzz']
        response = checker.are_all_fields_present(field_list)
        assert response == False

    def test_returns_false_if_more_fields_present_not_exact_match(self, checker):
        field_list = ['ptid', 'visitno', 'visit_modifier', 'fizzbuzz']
        response = checker.are_all_fields_present(field_list, require_exact_match=False)
        assert response == False

    def test_returns_true_if_fewer_fields_present_not_exact_match(self, checker):
        field_list = ['ptid', 'visitno']
        response = checker.are_all_fields_present(field_list, require_exact_match=False)
        assert response

    def test_must_have_at_least_one_field(self, checker):
        field_list = []
        response = checker.are_all_fields_present(field_list)
        assert response == False

class TestAreFieldContentsInList():

    @pytest.fixture
    def checker(self):
        df = pd.DataFrame({
            'fruit': ['apple', 'orange', 'pear', 'watermellon'],
            'vehicle': ['car', 'truck', 'motorcycle', 'bike'],
            'pear': ['hear', 'wear', 'where', 'ware']
        })
        chkr = DataFrameDataChecks(df)
        return chkr

    def test_all_fields_in_list(self, checker):
        fields = ['apple', 'pear', 'orange', 'watermellon']
        response = checker.are_field_contents_in_list('fruit', fields)
        assert response

    def test_returns_false_if_one_field_missing(self, checker):
        fields = ['apple', 'pear', 'orange']
        response = checker.are_field_contents_in_list('fruit', fields)
        assert response == False

    def test_returns_false_if_field_not_present(self, checker):
        fields = ['apple', 'pear', 'orange', 'water_buffalo']
        response = checker.are_field_contents_in_list('fruit', fields)
        assert response == False

    # NT is this the expected behavior?
    def test_returns_true_if_extra_field_present(self, checker):
        fields = ['apple', 'pear', 'orange', 'watermellon', 'grape']
        response = checker.are_field_contents_in_list('fruit', fields)
        assert response

class TestIsStringNumeric():
    
    @pytest.mark.parametrize("test_input,expected", [
        ('42', True),
        ('42.0', True),
        ('4.2E+1', True),
        ('4.2E1', True),
        ('4.2e1', True),
        ('420.0E-1', True),
        ('420.0e-1', True),
        ('-42', True),
        ('-42.0', True),
        ('-4.2E+1', True),
        ('-4.2e+1', True),
        ('-420.0E-1', True),
        ("fourtytwo", False),
        ("4D2", False),
        ("42.o", False),
        ("42.O", False), # capital  oh
    ])
    def test_is_string_numeric(self, test_input, expected):
        df = pd.DataFrame({
            'fruit': ['apple', 'orange', 'pear', 'watermellon'],
            'vehicle': ['car', 'truck', 'motorcycle', 'bike'],
            'pear': ['hear', 'wear', 'where', 'ware']
        })
        checker = DataFrameDataChecks(df)
        response = checker.is_string_numeric(test_input)
        assert response == expected

class TestIsFieldNumeric():

    @pytest.fixture
    def checker(self):
        df = pd.DataFrame({
            'all_nums': ['1', '2.0', '-3', '4E5', '-2.0e-8'],
            'no_nums': ['cat', 'dog', 'rat', 'bat', 'pig'],
            'mixed': ['2', 'fig', '3rd', 'three', '545J']
            })
        chkr = DataFrameDataChecks(df)
        return chkr

    def test_returns_true_if_all_values_are_numeric_in_field(self, checker):
        response = checker.is_field_numeric('all_nums')
        assert response

    def test_returns_false_if_all_values_are_not_numeric_in_field(self, checker):
        response = checker.is_field_numeric('no_nums')
        assert response == False

    def test_returns_false_if_some_values_are_not_numeric_in_field(self, checker):
        response = checker.is_field_numeric('mixed')
        assert response == False
#-----------------------------------------------------------------------------#

if __name__ == '__main__':
    pass