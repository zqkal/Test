#!/usr/local/apps/python/python-controlled/bin/python -tt

"""
Because of complexities with the interactions of our current version of python
with regards to pytest and python modules, this file allows for a common and
consistent means of adjusting the python import search path to include project
subdirectories. Ideally, this would not be necessary.

Also, some globals are defined, in order to point to data directories,
containing unit testing resources.
"""

import os
import sys

#-----------------------------------------------------------------------------#

THIS_DIR=os.path.dirname(os.path.realpath(__file__))

newdir = os.path.join(THIS_DIR, 'datachecks')
sys.path.append(newdir)

newdir = os.path.join(THIS_DIR, 'transformations')
sys.path.append(newdir)

newdir = os.path.join(THIS_DIR, 'pipelines')
sys.path.append(newdir)

newdir = os.path.join(THIS_DIR, 'pipelines', 'ldxnab001')
sys.path.append(newdir)

newdir = os.path.join(THIS_DIR, 'pipelines', 'ldxnab002')
sys.path.append(newdir)

newdir = os.path.join(THIS_DIR, 'pipelines', 'ldxelisapk003')
sys.path.append(newdir)

TEST_DIR = os.path.join(THIS_DIR, 'test')
UNITTEST_DATA_DIR = os.path.join(TEST_DIR, 'unittest_data')

# We are still using assay_report.py, should not be using other modules in this dir
CAP_PATH = '/trials/LabDataOps/managed_code/consolidated_assay_preprocessor'
sys.path.append(CAP_PATH)

#pt = ','.join(sys.path)
#print "(in import: debug info) path: " + pt + "\n\n\n"

