#!/usr/local/apps/python/python-controlled/bin/python -tt
"""  Pull out LDMS methods from assay_modules.py to us in ldx_io """


# TODO MW: create io/io/utils directory and move this file there
# potentially adjusting the imports file

import datetime
import numpy
import re
import pandas
import decimal
from decimal import Decimal
# suppress warning when using Pandas chained assignment
pandas.options.mode.chained_assignment = None
import pandas.util.testing as pdt
import pytest

#-----------------------------------------------------------------------------#

# CSDB is the name of the dataset that gets pulled in containing the LDMS data.
CSDB_PATH = '/trials/lp_work/reports/CSDBdata/hvtn.csdb.csv'
CSDB_PATH_TEST = '/trials/common/assay_code/LUM/testing_datasets/metadata/hvtn.csdb.csv'

LDMS_SPEC_FIELDS = {
    'guspec_ldms':'guspec',
    'network_ldms':'clasid',
    'protocol_ldms':'lstudy',
    'ptid_ldms':'txtpid',
    'visitno_ldms':'vidval',
    'drawdm_ldms':'drawdm',
    'drawdd_ldms':'drawdd',
    'drawdy_ldms':'drawdy',
    'spec_primary_ldms':'primstr',
    'spec_derivative_ldms':'dervstr',
    'spec_other_ldms':'sec_tp',
    'spec_additive_ldms':'addstr',
    'spec_subderivative_ldms':'dervst2',
    'labid_ldms':'labid',
    'collection_number_ldms':'addtim',
    'collection_category_ldms':'addunt',
    'collection_hour_ldms':'drawth',
    'collection_minute_ldms':'drawtm'
}

SPEC_FIELDS = {
    'network',
    'protocol',
    'ptid',
    'visitno',
    'drawdt',
    'collection_number',
    'collection_category',
    'collection_time',
    'spectype',
    'spec_primary',
    'spec_derivative',
    'spec_other',
    'spec_additive',
    'spec_subderivative'
}

SPEC_DICTIONARY = {
    ('BLD','PLA'): 'Plasma',
    ('BLD','SER'): 'Serum',
    ('REC','SPG'): 'Rectal Sponge',
    ('REC','SUP'): 'Rectal Biopsy',
    ('REC', 'SEC'): 'Rectal Secretions',
    ('REC','LYS'): 'Rectal Biopsy Lysate',
    ('VCS', 'FLD'): 'Softcup Fluid',
    ('CER','SPG'): 'Cervical Sponge',
    ('CER','SUP'): 'Cervical Biopsy',
    ('CER','LYS'): 'Cervical Biopsy Lysate',
    ('VAG','SUP'): 'Vaginal Biopsy',
    ('VAG','WCK'): 'Vaginal Weck',
    ('VAG','LYS'): 'Vaginal Biopsy Lysate',
    ('SAL','FLD'): 'Saliva',
    ('SAL','SAL'): 'Saliva',
    ('SEM','SEM'): 'Semen',
    ('SEM','FLD'): 'Semen',
    ('BLD','CEL'): 'PBMC',
    ('BLD', 'CSR'): 'Serum',
    ('BLD', 'DBS'): 'Dried Blood Spot'
}

#-----------------------------------------------------------------------------#

def add_ldms_values(assay_data, field_list):
    """ Add new columns to assay data using values from the LDMS.

    Args:
        assay_data (pandas.DataFrame): the assay data we wish to populate. Must 
            contain the GUSPEC field. Sample data only (all rows must have a valid
            guspec).
        field_list (list): field names for fields that will be populated by 
            LDMS. Names must exactly match the field names as they appear 
            in the LDMS. Fields must not already be present in assay data.

    Returns:
        A new dataframe, the input assay_data plus the fields from field_list. Rows that
        did not match LDMS (controls, bad GUSPEC) will have missing values (np.nan)
        in the added fields.

    Raises:
        KeyError if the field guspec missing from the assay data.
        ValueError if any field in field_list is already in the assay data.
        ValueError if any field in field_list is missing from the LDMS.
        RuntimeError if the number rows input do not match the number rows output.
    """

    # do some basic checks to make sure inputs are as expected
    if 'guspec' not in assay_data:
        err_msg = 'Input assay data must have a guspec field.'
        raise KeyError(err_msg)

    # do not overwite any assay_data
    if assay_data.columns.isin(field_list).any():
        err_msg = 'Tried to populate assay data with LDMS fields but fields already exist in assay data.'
        raise ValueError(err_msg)

    # define fields to be read in from LDMS dataset, include guspec for merge
    ldms_fields = field_list + ['guspec']

    # read in and do some clean up on the LDMS dataset
    try:
        csdb_data = pandas.read_csv(CSDB_PATH, dtype=str, na_values='', skipinitialspace=True, usecols=ldms_fields)
    except ValueError:
        err_msg = 'Values in field_list not found in LDMS: {}'.format(', '.join(field_list))
        raise ValueError(err_msg)

    """ 
    This is an example of the kind of duplicates that might be found if read in (guspec, x, y)
    
    guspec  x   y   z
    123     A   B   C   <- default action of pd.drop_duplicates() is keep first duplicate row
    123     A   B   C   <- drop
    123     A   B   D   <- drop
    """
    # TODO: investigate why this is ok. ST gave the ok to MW
    csdb_data = csdb_data.drop_duplicates()

    # merge assay and LDMS data on GUSPEC
    ds = pandas.merge(assay_data, csdb_data, how='left', left_on='guspec', right_on='guspec', indicator=True)

    # make sure we drop any extra rows added by pandas.merge
    return_fields = list(assay_data.columns) + field_list
    ds = ds[return_fields]

    # TODO: investigate why this is needed. This appears regularly in ST code
    ds = ds.drop_duplicates()

    # sanity check, # rows input should match # rows output!!
    if len(assay_data) != len(ds):
        err_msg = """
        Encountered a critical issue in add_ldms_values(), LDO-prog investigate.
        more rows in output than in input.
        """
        raise RuntimeError(err_msg)

    return d

class TestAddLDMSFields(object):
    """ Unit tests for assay_moduels.add_ldms_values() """

    def test_add_fields_and_values_to_assay_data(self):
        """ DEV NOTE: hand picked these GUSPECS and LDMS values from LDMS 12/4/2018 """
        assay_data = pandas.DataFrame({'guspec': ['GAZ070PR-01', '', 'misformed-guspec']})
        field_list = ['primstr']
        df_return = add_ldms_values(assay_data, field_list)
        df_expected = pandas.DataFrame({
            'guspec': ['GAZ070PR-01', '', 'misformed-guspec'], 
            'primstr': ['SEM', numpy.nan, numpy.nan]})
        pdt.assert_frame_equal(df_return, df_expected)

    def test_raise_key_error_if_guspec_field_not_in_assay_data(self):
        assay_data = pandas.DataFrame(columns=['primstr'])
        field_list = ['primstr']
        with pytest.raises(KeyError):
            add_ldms_values(assay_data, field_list)

    def test_raise_value_error_fields_already_in_assay_data(self):
        assay_data = pandas.DataFrame(columns=['guspec', 'primstr'])
        field_list = ['primstr']
        with pytest.raises(ValueError):
            add_ldms_values(assay_data, field_list)

    def test_raise_value_error_fields_missing_from_ldms(self):
        assay_data = pandas.DataFrame({'guspec': ['GAZ070PR-01']})
        field_list = ['this_is_not_an_ldms_field']
        with pytest.raises(ValueError):
            add_ldms_values(assay_data, field_list)


def ldms_merge(assay_data, prefer_db=True, testing=False):
    """ Check assay data against the LDMS.

    Usage:  merged_ds, discreps = assay_modules.ldms_merge(your_assay_ds)

    Note: do not use this method to add LDMS fields to the assay data, use 
          the method add_ldms_values.

    Args:
        assay_data: pandas DataFrame, assay dataset to check against LDMS.
        prefer_db: boolean, default True. Choose the LDMS value when the assay and
            LDMS values differ.
        testing: boolean, default False. Use archived CSDB testing dataset.

    Returns:
        A pandas DataFrame containing your assay data plus optionally some 
        values filled in from LDMS.

        A dictonary of record discrepancies found between the assay_data and LDMS.
        Keys are column names mapped to a list of dataframes that contain records 
        with discrepancies in that column.

    Raises: 
        ValueError if passed assay_data that is not a Pandas DataFrame or is
        an empty DataFrame.
    """
    if not isinstance(assay_data, pandas.DataFrame):
        raise ValueError('Non-DataFrame input passed to assay_modules.ldms_merge; no merge performed.')
    elif assay_data.empty:
        raise ValueError('Empty dataset passed to assay_modules.ldms_merge; no merge performed.')

    # Enables us to hit an archived CSDB copy if we're testing
    if testing:
        csdb_source = CSDB_PATH_TEST
    else:
        csdb_source = CSDB_PATH

    unmatched_guspecs = []
    discreps = {}               # discrepancy container

    csdb_data = pandas.read_csv(csdb_source, dtype=str, na_values='', skipinitialspace=True, usecols=LDMS_SPEC_FIELDS.values())

    # Rename columns and drop all full dups
    csdb_data.rename(columns={v:k for k, v in LDMS_SPEC_FIELDS.items()}, inplace=True)
    csdb_data = csdb_data.drop_duplicates()

    # Rename input columns for source clarity
    renamed_assay_data = assay_data.rename(columns={col:col + '_assay' for col in SPEC_FIELDS}, inplace=False)

    # Merge
    ds = pandas.merge(renamed_assay_data, csdb_data, how='left', left_on='guspec', right_on='guspec_ldms', indicator=True)
    
    # Check for unmatched guspecs
    if 'left_only' in ds['_merge'].unique():
        discreps['guspec'] = ds[ds['_merge'] != 'both']

        for e in discreps['guspec']['guspec'].unique():
            print "Global ID " + str(e) + " has no match in the CSDB."

    # Now drop all the unmatched ones since we don't need to do checks on them
    ds = ds[ds['_merge'] == 'both']

    # exit method if the merge was completely unsuccessful 
    if ds.empty:
        print 'LDMS merge failed due to bad Global ID match. Program will continue pre-processing without LDMS check.'
        return assay_data, discreps

    # Create consolidated drawdt_ldms, spectype_ldms, and collection_time_ldms
    ds['drawdt_ldms'] = ds.apply(lambda row: ldms_drawdt(row['drawdm_ldms'], row['drawdd_ldms'], row['drawdy_ldms']), axis=1)
    ds['spectype_ldms'] = ds.apply(lambda row: SPEC_DICTIONARY[(row['spec_primary_ldms'], row['spec_derivative_ldms'])], axis=1)
    ds['collection_time_ldms'] = ds.apply(lambda row: "%02d" % int(row['collection_hour_ldms']) + ':' + "%02d" % int(row['collection_minute_ldms']), axis=1)

    ds['network_ldms'] = ds.apply(lambda row: 'H' + row['network_ldms'], axis=1)

    for c in SPEC_FIELDS:
        if c == 'guspec':
            continue
        discreps[c] = pandas.DataFrame(columns=ds.columns)
        if c + '_assay' in ds.columns:
            ds[c] = ds.apply(lambda row: generic_check(row, c, discreps, prefer_db), axis=1)

    # Put the mismatched guspec rows back in, then send back only the columns we were sent
    if 'guspec' in discreps.keys():
        ds = ds.append(discreps['guspec'])
    ds = ds[assay_data.columns]

    # Crop full duplicates from the result  TODO: there's a more elegant fix for this that involves tailoring the columns pulled from LDMS to the
    # columns present in the input dataset.
    ds = ds.drop_duplicates()

    # Prune the discreps dictionary to only real discrepancies
    for key in discreps.keys():
        if discreps[key].empty:
            del discreps[key]

    return ds, discreps


def generic_check(row, col, discreps, prefer_db=True):
    """Check that assay and LDMS values match and choose LDMS value if there is a discrpancy.

    Append to the discrepancy dict if values are not equivalent, and by default 
    put the LDMS value in the return dataframe.

    If you do not want to overwrite with LDMS values, use the optional argument 
    prefer_db=False when you call the ldms_specmerge() method.

    Args:
        row: Pandas Series, row of dara to check. Should contain an assay and 
            LDMS column for a given column name, '<col>_assay' and '<col>_ldms'.
        col: string, name of the column whose value is being checked.
        discreps: dictionary, keys are column names mapped to rows containing 
            the discrpancy value.
        prefer_db: boolean, defaults to True. Choose LDMS value in the case of
            assay and LDMS discrpancy.

    Returns:
        The prefered value. If a discrepancy occurs betweeen the LDMS
        and assay values than discreps is updated through reference.
    """

    # Cases with blank entries in LDMS
    if pandas.isnull(row[col + '_ldms']) or row[col + '_ldms'] == '':
        return row[col + '_assay']

    date_fields = [
        'drawdt',
        'testdt',
        'effector_cells_date_thawed',
        'target_cells_date_thawed',
        'tci_start_date',
        'hc_infection_start_date',
        'vs_harvest_date'
    ]

    # Set up the parsed values
    if col in date_fields:
        ldms_value = to_mmddyyyy(row[col +'_ldms'])
        if pandas.isnull(row[col + '_assay']) or row[col + '_assay'] == '':
            return ldms_value
        assay_value = to_mmddyyyy(row[col + '_assay'])
        
    elif col == 'protocol':
        try:
            ldms_value = "%03d" % Decimal(row[col +'_ldms'])
            # if LDMS value is castable we should also try casting the assay value
            try_casting_assay_value = True
        except (decimal.InvalidOperation, TypeError):
            ldms_value = row[col +'_ldms']
            try_casting_assay_value = False

        # cannot cast ampty or null values to Decimal
        if pandas.isnull(row[col + '_assay']) or row[col + '_assay'] == '':
            return ldms_value
        if try_casting_assay_value:
            try:
                assay_value = "%03d" % Decimal(row[col + '_assay'])
            except (decimal.InvalidOperation, TypeError):
                assay_value = row[col + '_assay']
                ldms_value = row[col +'_ldms']
        else:
            assay_value = str(row[col + '_assay'])

    elif col == 'visitno':
        try:
            ldms_value = "%g" % Decimal(row[col +'_ldms'])
            # if LDMS value is castable we should also try casting the assay value
            try_casting_assay_value = True
        except (decimal.InvalidOperation, TypeError):
            ldms_value = row[col +'_ldms']
            try_casting_assay_value = False

        # cannot cast ampty or null values to Decimal
        if pandas.isnull(row[col + '_assay']) or row[col + '_assay'] == '':
            return ldms_value
        if try_casting_assay_value:
            try:
                assay_value = "%g" % Decimal(row[col + '_assay'])
            except (decimal.InvalidOperation, TypeError):
                assay_value = row[col + '_assay']
                ldms_value = row[col +'_ldms']
        else:
            assay_value = str(row[col + '_assay'])

    elif col == 'ptid':
        try:
            ldms_value = str(Decimal(row[col +'_ldms']))
            # if LDMS value is castable we should also try casting the assay value
            try_casting_assay_value = True
        except (decimal.InvalidOperation, TypeError):
            ldms_value = row[col +'_ldms']
            try_casting_assay_value = False

        # cannot cast ampty or null values to Decimal
        if pandas.isnull(row[col + '_assay']) or row[col + '_assay'] == '':
            return ldms_value
        if try_casting_assay_value:
            try:
                assay_value = str(Decimal(row[col + '_assay']))
            except (decimal.InvalidOperation, TypeError):
                assay_value = row[col + '_assay']
                ldms_value = row[col +'_ldms']
        else:
            assay_value = str(row[col + '_assay'])
    else:
        ldms_value = row[col +'_ldms']
        if pandas.isnull(row[col + '_assay']) or row[col + '_assay'] == '':
            return ldms_value
        assay_value = str(row[col + '_assay'])

    # Do the actual checking
    if assay_value == ldms_value:
        return row[col + '_assay']
    elif prefer_db:
        discreps[col] = discreps[col].append(row)
        return ldms_value
    else:
        discreps[col] = discreps[col].append(row)
        return row[col + '_assay']

def to_mmddyyyy(s):
    """Attempts to parse dates out of various formats and return in MM/DD/YYYY.
    Formats covered include YYYY/MM/DD, YYYY-MM-DD, and MM/DD/YY.
    """
    if pandas.isnull(s) or s == '':
        return ''

    if isinstance(s, datetime.datetime):
        return '/'.join(["%02d" % s.month, "%02d" % s.day, str(s.year)])

    #mm/dd/yyyy
    date_pat_preferred = r'(\d{1,2})[/-](\d{1,2})[/-](\d{4})'

    #yyyy/mm/dd
    date_pat1 = r'(\d{4})[/-](\d{1,2})[/-](\d{1,2})'

    #mm/dd/yy
    date_pat2 = r'(\d{1,2})[/-](\d{1,2})[/-](\d{2})'

    #dd-mmm-yyyy
    date_pat3 = r'(\d{1,2})-(\w{3})-(\d{4})'

    #dd-mmm-yy
    date_pat4 = r'(\d{1,2})-(\w{3})-(\d{2})'

    #dd/mmm/yyyy or dd-mmm-yyyy
    date_pat5 = r'(\d{1,2})[/-](\w{3})[/-](\d{4})'

    #dd/mmm/yy or dd-mmm-yy
    date_pat6 = r'(\d{1,2})[/-](\w{3})[/-](\d{2})'

    date_match_preferred = re.search(date_pat_preferred, s)
    date_match1 = re.search(date_pat1, s)
    date_match2 = re.search(date_pat2, s)
    date_match3 = re.search(date_pat3, s)
    date_match4 = re.search(date_pat4, s)
    date_match5 = re.search(date_pat5, s)
    date_match6 = re.search(date_pat6, s)


    if date_match_preferred:
        return "%02d" % int(date_match_preferred.group(1)) + '/' + "%02d" % int(date_match_preferred.group(2)) + '/' + date_match_preferred.group(3)
    elif date_match1:
        return "%02d" % int(date_match1.group(2)) + '/' + "%02d" % int(date_match1.group(3)) + '/' + date_match1.group(1)
    elif date_match2:
        return "%02d" % int(date_match2.group(1)) + '/' + "%02d" % int(date_match2.group(2)) + '/' + '20' + date_match2.group(3)
    elif date_match3:
        return "%02d" % MONTHS_BY_FIRST_THREE[date_match3.group(2).lower()] + '/' + "%02d" % int(date_match3.group(1)) + '/' + date_match3.group(3)
    elif date_match4:
        return "%02d" % MONTHS_BY_FIRST_THREE[date_match4.group(2).lower()] + '/' + "%02d" % int(date_match4.group(1)) + '/20' + date_match4.group(3)
    elif date_match5:
        return "%02d" % MONTHS_BY_FIRST_THREE[date_match5.group(2).lower()] + '/' + "%02d" % int(date_match5.group(1)) + '/' + date_match5.group(3)
    elif date_match6:
        return "%02d" % MONTHS_BY_FIRST_THREE[date_match6.group(2).lower()] + '/' + "%02d" % int(date_match6.group(1)) + '/20' + date_match6.group(3)
    else:
        return s

def ldms_drawdt(drawdm, drawdd, drawdy):
    """Takes LDMS-formatted month, day, and year and returns as MM/DD/YYYY. """
    if pandas.isnull(drawdm) or pandas.isnull(drawdd) or pandas.isnull(drawdy):
        return ''
    else: 
        return "%02d" % int(drawdm) + '/' + "%02d" % int(drawdd) + '/' + drawdy

#-----------------------------------------------------------------------------#

if __name__ == '__main__':
    pass