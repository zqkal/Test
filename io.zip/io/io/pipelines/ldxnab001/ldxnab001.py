#!/usr/local/apps/python/python-controlled/bin/python -tt

"""  Main LDXNAB001 control flow. """

import logging
logging.basicConfig(level=logging.DEBUG, format='%(asctime)s\t[%(levelname)s]\t%(message)s', datefmt='%d-%b-%y %H:%M:%S')
log = logging.getLogger(__name__)
import datetime
from glob import glob
import os
import pandas as pd
import re
import sys


import imports

import ldms_utils
from data_frame_transformations import DataFrameTransformations
from data_checks import DataFrameDataChecks
from ldxnab001_lab_data_file import LDXNAB001LabDataFile
from ldxnab001_auxillary_data_file import LDXNAB001AuxillaryDataFile

# TODO: Move this path to imports?
sys.path.append('/trials/LabDataOps/managed_code/consolidated_assay_preprocessor')
import assay_report

#-----------------------------------------------------------------------------#

class LDXNAB001Pipeline:

    ordered_output_field_list = [
        'network',
        'protocol',
        'labid',
        'assayid',
        'alternative_specid',
        'specid',
        'ptid',
        'visitno',
        'drawdt',
        'assaytyp',
        'assayrun',
        'celltype',
        'isolate',
        'infunits',
        'poscrit',
        'cutoff',
        'titer',
        'testdt',
        'reliable',
        'replace',
        'moddt',
        'comments',
        'hostcell',
        'backbone',
        'interpretmethod',
        'virustype',
        'virusdilution',
        'concentration_units',
        'assay_method',
        'harvestdate',
        'virusid',
        'incubation',
        'experimenter',
        'platenum',
        'mablotnum',
        'initdilution',
        'dilutionfactor',
        'instrument_filename'
    ]

    def __init__(self, network, protocol, assay, lab_id):
        self.network = network
        self.protocol = protocol
        self.assay = assay
        self.lab_id = lab_id

        self.lab_data_filename = ''
        self.output_data_path = ''

        self.auxillary_data_filename = ''

        self.lab_data_file = LDXNAB001LabDataFile()
        self.auxillary_data_file = LDXNAB001AuxillaryDataFile()

        self.data_frame = pd.DataFrame()

    def run(self):
        """ orchestrate the pipeline. """
        
        self.read_input_files()

        self.check_input_data()

        self.pre_merge_input_data_transformations()

        # self.pre_merge_data_checks() # not relevant for LDXNAB001

        self.merge_data()

        self.post_merge_data_transformations()

        self.ldms_lookup()

        self.post_merge_data_checks()

        self.pre_output_transformations()

        self.generate_pipeline_output()

    # record the basics: i/o filenames
    def setup(self, input_data_filename, output_data_path):
        self.lab_data_filename = input_data_filename
        self.output_data_path = output_data_path

        if ((self.network == 'HVTN' and self.protocol == '703')
            or
            (self.network == 'HPTN' and self.protocol == '081')):

            self.auxillary_data_filename = '/trials/LabDataOps/assay_information/NAB-LDOGEN-50-DEVEL/WARNING_POTENTIALLY_UNBLINDING_stats_lists/HVTN703_Autologous_Neuts_Serum_for_NICD_withLabel.csv'
        elif ((self.network == 'HVTN' and self.protocol == '704')
            or
            (self.network == 'HPTN' and self.protocol == '085')):
            self.auxillary_data_filename = '/trials/LabDataOps/assay_information/NAB-LDOGEN-50-DEVEL/WARNING_POTENTIALLY_UNBLINDING_stats_lists/HVTN_704_Autologous_Neuts_Serum_for_Duke_withLabel.csv'

        if not self.lab_data_file.set_filename(self.lab_data_filename):
            # TODO log
            log.error('could not set lab data file to {}'.format(self.lab_data_filename))
            sys.exit(-1)

        if not self.auxillary_data_file.setup(self.auxillary_data_filename, self.network, self.protocol):
            # TODO log
            log.error('could not set auxillary data file to {}'.format(self.auxillary_data_filename))
            sys.exit(-1) 

    def read_input_files(self):
        self.auxillary_data_file.read_file()
        self.lab_data_file.read_file()

    def check_input_data(self):
        checks_result = self.auxillary_data_file.check_input_data()
        if not checks_result:
            log.error('Expected fields missing from Auxillary data file. Exiting program...')
            sys.exit(-1)

        checks_result = self.lab_data_file.check_input_data()
        if not checks_result:
            log.error('Expected fields missing from Lab data file. Exiting program...')
            sys.exit(-1)

    def pre_merge_input_data_transformations(self):
        self.auxillary_data_file.transform_data()
        self.lab_data_file.transform_data()

    def pre_merge_data_checks(self):
        self.auxillary_data_file.check_data_after_transformations()
        self.lab_data_file.check_data_after_transformations()
        return False

    def merge_data(self):
       
        merge_field = 'alternative_specid'

        # useful debbugging output
        # output_filename = os.path.join(self.output_data_path, 'premerge-labdata.tsv')
        # self.lab_data_file.data_frame.to_csv(output_filename, sep='\t', index=False)

        # useful debbugging output
        # output_filename = os.path.join(self.output_data_path, 'premerge-auxdata.tsv')
        # self.auxillary_data_file.data_frame.to_csv(output_filename, sep='\t', index=False)

        # output_filename = '/scharp/devel/ldx/io/io/test_data_out.tsv'
        # log.info('writing preprocessor output to {}'.format(output_filename))
        # self.data_frame.to_csv(output_filename, sep='\t', index=False)

        self.data_frame = pd.merge(
            self.lab_data_file.data_frame,
            self.auxillary_data_file.data_frame,
            how = 'outer', # use union of fields from both frames
            on = merge_field,
            indicator = True # yes, add '_merge' field with records of right_only, etc
            ) 

        # report unmatched rows on either side  
        lab_data_only_rows = self.data_frame[self.data_frame['_merge'] == 'left_only']
        auxillary_data_only_rows = self.data_frame[self.data_frame['_merge'] == 'right_only']

        lab_data_only_count = lab_data_only_rows.shape[0]
        auxillary_data_only_row_count = auxillary_data_only_rows.shape[0]

        if lab_data_only_count > 0:
            logging.warn('%d lab data rows were unmatched against the auxillary data', lab_data_only_count)
            output_filename = os.path.join(self.output_data_path, 'WARN_lab_data_only_rows.tsv')
            lab_data_only_rows.to_csv(output_filename, sep='\t', index=False)
            logging.warn('wrote lab data only report to %s', output_filename)
        else:
            logging.info('all lab data rows had matches with the auxillary data')

        if auxillary_data_only_row_count > 0:
            logging.warn('%d auxillary data rows did not have matches against the lab data', auxillary_data_only_row_count)
            output_filename = os.path.join(self.output_data_path, 'WARN_auxillary_data_only_rows.tsv')
            auxillary_data_only_rows.to_csv(output_filename, sep='\t', index=False)
            logging.warn('wrote instrument-only report to %s', output_filename)
        else:
            logging.info('all auxillary data rows have matches with the lab data')

        # only keep rows with primary keys in both meta and instrument 
        self.data_frame = self.data_frame[self.data_frame['_merge']=='both']
        if (lab_data_only_count > 0) or (auxillary_data_only_row_count > 0):
            logging.warn('unmatched rows were dropped; proceeding')

        # clean up after the merge
        transformer = DataFrameTransformations(self.data_frame)
        transformer.drop_field('_merge') # delete the info column added by pandas merge()
    
    def post_merge_data_transformations(self):
        pass
        # ??? Test Date > testdt
        # not found in post-merge data

    def pre_output_transformations(self):
        transformer = DataFrameTransformations(self.data_frame)
    
        # select a subset of fields, reorder, and discard the rest
        # TODO: move this into transfomrations, vurrently issue with refernce of DF
        for field in self.ordered_output_field_list:
            if field not in self.data_frame:
                raise KeyError('{} field missing from DataFrame'.format(field))
        self.data_frame = self.data_frame[self.ordered_output_field_list]

    def post_merge_data_checks(self):
        data_checker = DataFrameDataChecks(self.data_frame)

        required_field_list = [
            'network', 'protocol', 'labid', 'alternative_specid', 'specid', 
            'ptid', 'visitno', 'drawdt', 'assaytyp', 'assayrun','celltype', 
            'isolate', 'poscrit', 'cutoff', 'titer', 'testdt', 'reliable', 
            'replace', 'hostcell', 'backbone', 'interpretmethod', 'virustype', 
            'virusdilution', 'assay_method', 'harvestdate', 'virusid', 
            'incubation', 'platenum', 'initdilution', 'dilutionfactor', 
            'instrument_filename']

        check_result_list = []

        for field in required_field_list:
            check_result_list.append(data_checker.are_field_values_not_blank(field))

        check_result_list.append(data_checker.is_virusid_field_conditionally_not_blank())

        # TODO: gather the result and log '!!! data check failure but producing with output, do not send data to stats'

    def ldms_lookup(self):
        """ """ 
        log.info('Running LDMS merge')
        datestring = str(datetime.date.today()).replace('-', '')

        # ldms_merge expects the field 'guspec' to erge on CSDB
        # we temp renme this var for this pipeline
        self.data_frame.rename(columns={'specid': 'guspec'}, inplace=True)
        # ldms_merge will replace any values in input DataFrame that do not
        # match the values in the LDMS
        self.data_frame, discrep_dict = ldms_utils.ldms_merge(self.data_frame)

        # revert field nameing
        self.data_frame.rename(columns={'guspec': 'specid'}, inplace=True)

        #report LDMS discreps
        for field in discrep_dict.keys():
            discrep_report_path = os.path.join(self.output_data_path, '{}_discreps_{}.txt'.format(field, datestring))
            log.warning('LDMS merge issue found, generating discrep report here: {}'.format(discrep_report_path))
            discrep_dict[field].to_csv(discrep_report_path, sep='\t', index=False)
        log.info('LDMS merge complete')

    def generate_pipeline_output(self):
        # TODO: get from cmdline args!!!
        # TODO: label file as DRAFT if any checks fail
        # TODO: 

        # TODO get format
        datestring = str(datetime.date.today()).replace('-', '')

        short_network_abbreviation = ''
        long_to_short_network_names = {
            'HVTN' : 'VTN',
            'HPTN' : 'PTN',
            'CAVD' : 'CVD'
        }

        if self.network in long_to_short_network_names:
            short_network_abbreviation = long_to_short_network_names[self.network]
        else:
            short_network_abbreviation = self.network

        log.debug('given network abbr: ' + self.network)
        log.debug('shortened network abbr:' + short_network_abbreviation)

        # VTN_AIDNAB01<LAB_ID><date_YYYYMMDD>E001.txt
        
        output_pattern = '{}_AIDNAB01{}{}E???.txt'.format(short_network_abbreviation, self.lab_id, datestring)
        output_pattern_fullpath = os.path.join(self.output_data_path, output_pattern)
        


        # does pattern exist?
        
        E_number = '' # default first in series
        matches = glob(output_pattern_fullpath)
        if len(matches) > 0:
            # if so, pick the lexigraphically last one

            log.debug('found {} similar-ly named output file(s)'.format(len(matches)))
            matches.sort()
            log.debug('matches: {}'.format(','.join(matches)))
            last_match = matches[-1]
            log.debug('found highest existing filename in output dir: {}'.format(last_match))
            match_pattern = r'[a-zA-Z0-9_]*(\d{3}).txt'
            match = re.search(match_pattern, last_match)
            last_e_num = match.group(1)
            log.debug('last e sequence number: {}'.format(last_e_num))

            last_e_num_int = int(last_e_num)
            new_e_num_int = last_e_num_int + 1
            log.debug('new e num (int): {}'.format(new_e_num_int))
            E_number = "%03d" % new_e_num_int
            log.debug('using new e seq string: {}'.format(E_number))
        else:
            # start with the first in the series
            E_number = '001'

        output_filename = '{}_AIDNAB01{}{}E{}.txt'.format(short_network_abbreviation, self.lab_id, datestring, E_number)
        output_fullpath = os.path.join(self.output_data_path, output_filename)
        log.info('writing preprocessor output to {}'.format(output_fullpath))
        self.data_frame.to_csv(output_fullpath, sep='\t', index=False)

        # generate a summary report
        summary_fullpath = '{}_summary_report.xlsx'.format(output_fullpath.strip('.txt'))
        assay_report.make_assay_report(self.data_frame, 'ldxnab001', summary_fullpath)
        log.info('writing summary report output to {}'.format(summary_fullpath))
