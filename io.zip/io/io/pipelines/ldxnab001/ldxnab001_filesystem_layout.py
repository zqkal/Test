#!/usr/local/apps/python/python-controlled/bin/python -tt

""" TODO (NT): File description. """

import logging
log = logging.getLogger(__name__)

#-----------------------------------------------------------------------------#

class LDXNAB001FileSystemLayout:

    def __init__(self):
        pass

    expected_input_directories = [
        'lab_submissions'
        # example:
        # 'lab_submissions/instrument_files'
    ]

    expected_output_directories = [
        'processor_output',
        'processor_output/datasets',
        'processor_output/reports',    
    ]
