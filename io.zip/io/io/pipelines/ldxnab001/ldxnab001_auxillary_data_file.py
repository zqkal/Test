#!/usr/local/apps/python/python-controlled/bin/python -tt

""" TODO: file header """

import logging
logging.basicConfig(level=logging.DEBUG, format='%(asctime)s\t[%(levelname)s]\t%(message)s', datefmt='%d-%b-%y %H:%M:%S')
log = logging.getLogger(__name__)

import numpy as np
import pandas as pd
import pytest
import re
import sys

# TODO: figure out how to get this working
# so that this file can be run for it's main() test
#sys.path.append('/scharp/devel/ldx/io/io')

import imports
from data_frame_transformations import DataFrameTransformations
from data_checks import DataFrameDataChecks

#-----------------------------------------------------------------------------#

class LDXNAB001AuxillaryDataFile:

    def __init__(self):        
        self.filename = ''
        self.network = ''
        self.protocol = ''
        self.lab_id = ''
        self.data_frame = pd.DataFrame()

    def setup(self, filename, network, protocol):

        self.filename = filename
        self.network = network
        self.protocol = protocol
        self.expected_input_fields = []
        self.fields_to_rename = {}
        
        if ((self.network == 'HVTN' and self.protocol == '703')
            or
            (self.network == 'HPTN' and self.protocol == '081')):

            self.expected_input_fields = self.expected_input_fields_HVTN703_HPTN_081
            self.fields_to_rename = self.fields_to_rename_HVTN703_HPTN_081
        elif ((self.network == 'HVTN' and self.protocol == '704')
            or
            (self.network == 'HPTN' and self.protocol == '085')):

            self.expected_input_fields = self.expected_input_fields_HVTN704_HPTN_085
            self.fields_to_rename = self.fields_to_rename_HVTN704_HPTN_085
        else:
            return False

        return True

    # TODO make this parse a stream;
    # if you want to read from file, first make a stream from the
    def read_file(self, input_source=None):
        # TODO any error checking at all

        if input_source == None:
            input_source = self.filename
            log.info('loading auxillary data from {}'.format(self.filename))
        else:
            log.info('loading auxillary data from stream object')

        self.data_frame = pd.read_csv(
            filepath_or_buffer = input_source, 
            sep = self.field_separator, 
            dtype = str, 
            na_values = np.nan, 
            keep_default_na=False, 
            header=0)
        log.info('done loading auxillary data');

    def check_input_data(self):
        data_checker = DataFrameDataChecks(self.data_frame)

        # Define network/protocol specific fields to check
        fields_to_check = []
        if ((self.network == 'HVTN' and self.protocol == '703') or
            (self.network == 'HPTN' and self.protocol == '081')):
            fields_to_check = self.expected_input_fields_HVTN703_HPTN_081
        if ((self.network == 'HVTN' and self.protocol == '704') or
            (self.network == 'HPTN' and self.protocol == '085')):
            fields_to_check = self.expected_input_fields_HVTN704_HPTN_085
        if not fields_to_check:
            raise ValueError('check_input_data not configured for network/protocol')

        check_result_list = []
        for field in fields_to_check:
            check_result_list.append(data_checker.is_field_present(field))
        # If any check was False, cumulative result will aslo be False
        cumulative_result = all(check_result_list)

        return cumulative_result

    def transform_data(self):
        log.info('transforming auxillary data')

        # TF1 - part 1/2
        # part 2/2 continues in ldxnab001 pipeline class,
        # in the merge function that combines data from
        # the lab data and the auxillary data files

        # the remaining fields will be merged into the
        # lab data file
        self.drop_unnecessary_fields()
        self.rename_fields()

        # TF5 - part 2/2
        # part 1 takes place in the lab data file transformations,
        # where TESTDT and HARVESTDATE are processed
        self.reformat_date_field()

        # TF8
        self.downcase_all_fields()

        log.debug('done transforming auxillary data')

    def check_data_after_transformations(self):
        return False

    def drop_unnecessary_fields(self):
        log.debug('dropping auxillary data unnecessary fields')
        # expectation: call this BEFORE fields are renamed

        # TODO make sure there's anything to drop after this:
        fields_to_drop = list(set(self.expected_input_fields).
            difference(set(self.fields_to_rename.keys())))

        log.debug('fields to drop: ' + ','.join(fields_to_drop))
        transformer = DataFrameTransformations(self.data_frame)
        transformer.drop_fields(fields_to_drop)
        #print transformer.data_frame.head()
        log.debug('done dropping auxillary data unnecessary fields')

    def rename_fields(self):
        log.debug('renaming auxillary data fields')
        transformer = DataFrameTransformations(self.data_frame)

        for original_name, new_name in self.fields_to_rename.iteritems():
            transformer.rename_field_name(original_name, new_name, replace=True)
        log.debug('done renaming auxillary data fields')
    
    def downcase_all_fields(self):
        log.debug('downcasing all fields')
        transformer = DataFrameTransformations(self.data_frame)
        for field in list(self.data_frame.columns):
            transformer.down_case_field_name(field)
        log.debug('done downcasing all fields')

    def reformat_date_field(self):
        log.debug('reformating date field')
        transformer = DataFrameTransformations(self.data_frame)
        transformer.format_date_field('drawdt', '%m/%d/%Y', '%m/%d/%y')
        log.debug('done reformating date field')

    # Class variables defined here:

    field_separator = ','

    expected_input_fields_HVTN704_HPTN_085 = [
        'Study_ID',
        'Subject_Id',
        'Original_Id',
        'Date_Drawn',
        'Vial_Status',
        'Visit',
        'Volume',
        'Material_Type',
        'Material_Modifiers',
        'Vial_Modifiers',
        'BSI_ID',
        'count',
        'Label'
    ]

    expected_input_fields_HVTN703_HPTN_081 = [
        'Protocol_Number',
        'Participant_Id',
        'Global_Unique_Id',
        'Draw_Timestamp',
        'sequencenum',
        'Volume',
        'Volume_units',
        'Primary_Type',
        'Derivative_type2',
        'Additive_Type',
        'Label'
    ]

    # original field name : new field name
    fields_to_rename_HVTN704_HPTN_085 = {
        'Subject_Id' : 'ptid',
        'Original_Id' : 'specid',
        'Date_Drawn' : 'drawdt',
        'Visit' : 'visitno',
        'Label' : 'alternative_specid'
    }

    fields_to_rename_HVTN703_HPTN_081 = {
        'Participant_Id' : 'ptid',
        'Global_Unique_Id' : 'specid',
        'Draw_Timestamp' : 'drawdt',
        'sequencenum' : 'visitno',
        'Label' : 'alternative_specid'
    }


# class TestParseFilename:
        
#     def test_parse_filename_with_good_input(self):
#         filename = 'VTN704_AIDNABDU20190104001_A.tsv'
      
#         file_parser = LDXNAB001InputFileParser()
        
#         file_parser.setup_input_from_filename(filename)

#         extracted_data = [file_parser.network, file_parser.protocol, file_parser.assay_code, file_parser.lab_id, \
# file_parser.year_number, file_parser.month_number, file_parser.day_number, file_parser.file_sequence_number, file_parser.file_version_code]
        
#         expected_data = \
#         ['VTN','704','AIDNAB','DU', '2019','01','04','001', 'A']


#         assert expected_data == extracted_data


#     def test_parse_filename_with_good_input_delete(self):
#         filename = 'VTN704_AIDNABDU20190104001_DELETE.tsv'
      
#         file_parser = LDXNAB001InputFileParser()
        
#         file_parser.setup_input_from_filename(filename)

#         extracted_data = [file_parser.network, file_parser.protocol, file_parser.assay_code, file_parser.lab_id, \
# file_parser.year_number, file_parser.month_number, file_parser.day_number, file_parser.file_sequence_number, file_parser.file_version_code]
        
#         expected_data = \
#         ['VTN','704','AIDNAB','DU', '2019','01','04','001', 'DELETE']


#         assert expected_data == extracted_data

#     def test_parse_filename_with_bad_input(self):
#         filename = 'VTN04_AIDNABDU20190104001_A.tsv'
      
#         file_parser = LDXNAB001InputFileParser()
        
#         assert file_parser.setup_input_from_filename(filename) == False



# class TestReadFile:
#     def test_parse_stream_with_good_structure(self):
#         # create a string representation of a file, without regards to datatypes

#         data = '\t'.join(LDXNAB001InputFileParser.expected_input_fields)
#         data = data + '\t'.join(range(len(LDXNAB001InputFileParser.expected_input_fields)))
#         parser = LDXNAB001InputFileParser()


#         # TODO
#         #strstream = StringIO.StringIO(data)
#         #parser.read_tsv(strstream)

#         #print parser.data_frame.head()
#         assert False


#     def test_parse_stream_with_bad_tsv_format(self):
#         assert False

#     def test_parse_stream_with_too_many_columns(self):
#         assert False

#     def test_parse_stream_with_too_few_columns(self):
#         assert False

def main():
    # do some tests
    log.debug("testing aux file")
    aux_file = LDXNAB001AuxillaryDataFile()

    test_filename = '/trials/LabDataOps/assay_information/NAB-LDOGEN-50-DEVEL/WARNING_POTENTIALLY_UNBLINDING_stats_lists/HVTN_704_Autologous_Neuts_Serum_for_Duke_withLabel.csv'

    aux_file.setup(test_filename, 'HVTN', '704')

    aux_file.read_file()
    aux_file.transform_data()

    print aux_file.data_frame.head()

    log.debug("done testing aux file")

#-----------------------------------------------------------------------------#

if __name__ == '__main__':
    main()