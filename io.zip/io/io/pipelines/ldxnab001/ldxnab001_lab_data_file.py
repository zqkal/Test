#!/usr/local/apps/python/python-controlled/bin/python -tt
# -*- coding: utf-8 -*-
""" TODO: file header"""

import logging
logging.basicConfig(level=logging.DEBUG, format='%(asctime)s\t[%(levelname)s]\t%(message)s', datefmt='%d-%b-%y %H:%M:%S')
log = logging.getLogger(__name__)

import numpy as np
import pandas as pd
import pytest
import re
import StringIO
import sys

# TODO: figure out how to get this working
# so that this file can be run for it's main() test
#sys.path.append('/scharp/devel/ldx/io/io')
import imports
from data_frame_transformations import DataFrameTransformations
from data_checks import DataFrameDataChecks

#-----------------------------------------------------------------------------#

class LDXNAB001LabDataFile:

    def __init__(self):
        self.data_frame = pd.DataFrame()
        self.filename = ''
        self.network = ''
        self.protocol = ''
        self.assay_code = ''
        self.lab_id = ''
        self.month_number = -1
        self.day_number = -1
        self.year_number = -1
        self.file_sequence_number = -1
        self.file_version_code = ''

    def parse_filename(self):
        """
        VTN<protocol>_AIDNAB<LABID><DATE><file sequence>_<Version>.tsv

        e.g.

        VTN704_AIDNABDU20190104001_A.tsv

        DATE = YYYYMMDD (year, month, and day the file was created). E.g. May 28, 2012 = 20120528 
        Experiment Name = The experiment id or assay ID
        File Sequence = a number differentiating files when multiple files are submitted on the same day
        
        Submission Version = Letter (A-Z) to designate the version of the files. Replacement files should
        use the letter after the one in the file being replaced, e.g. "B". To delete a previously
        submitted file, submit a file with the same name with the version "DELETE"
        """

        network_pattern = r'([A-Z]{3,4})'
        protocol_pattern = r'([0-9]{3})'

        # TODO: check if 5, 6, 5 to 6
        assay_code_pattern = r'([A-Z]{6})'

        # TODO: check with anisa
        lab_id_pattern = r'([A-Z]{2})'
       
        #yyyymmdd
        date_pattern = r'(\d{4})(\d{2})(\d{2})'

        file_sequence_pattern = r'([0-9]{3})'

        # TODO: allow 'DELETE'
        file_version_code_pattern = r'(DELETE|[A-Z])'

        filename_pattern = network_pattern + protocol_pattern + '_' + assay_code_pattern + \
                          lab_id_pattern + date_pattern + file_sequence_pattern + '_' + file_version_code_pattern

        log.debug('using filename pattern regex {}'.format(filename_pattern))
        print 'using filename pattern regex {}'.format(filename_pattern)
        filename_parse_match = re.search(filename_pattern, self.filename)

        if not filename_parse_match:
            # TODO logging
            return False
        else:
            self.network = filename_parse_match.group(1)
            self.protocol = filename_parse_match.group(2)
            self.assay_code = filename_parse_match.group(3)
            self.lab_id = filename_parse_match.group(4)
            self.year_number = filename_parse_match.group(5)
            self.month_number = filename_parse_match.group(6)
            self.day_number = filename_parse_match.group(7)
            self.file_sequence_number = filename_parse_match.group(8)
            self.file_version_code = filename_parse_match.group(9)

            logging.info(
                'parsed information from filename: network = {},\protocol = {},\
                 assay_code = {}, lab_id = {}, year_number = {}, month_number = {},\
                 day_number = {}, file_sequence_number = {}, file_version_code = {}'.format(
                    self.network, self.protocol, self.assay_code, self.lab_id,
                    self.year_number, self.month_number, self.day_number, 
                    self.file_sequence_number, self.file_version_code))
            return True

    def set_filename(self, filename):
        # TODO split path and save directory too
        # TODO ensure file exists
    
        self.filename = filename

        if not self.parse_filename():
            # error
            return False
        else:
            return True

    # TODO make this parse a stream;
    # if you want to read from file, first make a stream from the
    def read_file(self, input_source=''):
        # TODO any error checking at all

        if input_source == '':
            input_source = self.filename

        self.data_frame = pd.read_csv(
            filepath_or_buffer = input_source, 
            sep = self.field_separator, 
            dtype = str, 
            na_values = np.nan, 
            keep_default_na=False, 
            header=0)

    def check_input_data(self):
        data_checker = DataFrameDataChecks(self.data_frame)
        fields_to_check = self.expected_input_fields
        check_result_list = []
        for field in fields_to_check:
            check_result_list.append(data_checker.is_field_present(field))
        # If any check was False, cumulative result will aslo be False
        cumulative_result = all(check_result_list)
        return cumulative_result

    def transform_data(self):
        transformer = DataFrameTransformations(self.data_frame)

        # TODO: break into subfunctions, if desired

        # TF1 - part 1/2
        # part 2/2 continues in ldxnab001 pipeline class,
        # in the merge function that combines data from
        # the lab data and the auxillary data files

        # these will be replaced by merging with the aux data file
        # (in the ldxnab001 pipeline class)

        #print self.data_frame.head()
        fields_to_drop = ['PTID', 'VISITNO', 'DRAWDT', 'RUN_COMMENTS']
        transformer.drop_fields(fields_to_drop)

        # TF2
        self._fill_empty_values_in_isolate_field_with_virusnameother()
        
        # TF3
        self._melt_titrate_fields()

        # TF3
        self._parse_poscrit_field()

        # TODO: see if we can't do a copy or something, on the above function,
        # to emulate "in place". Otherwise, melt replaces the df, and we have to use
        # a new transformer for the new, replaced, df
        transformer = DataFrameTransformations(self.data_frame)

        # TF4
        transformer.rename_field_name('MABLOT', 'MABLOTNUM')

        # TF5 - part 1 /2
        # part 2 takes place in the aux file transformations,
        # where DRAWDT is processed
        date_fields_to_reformat = ['TESTDT', 'HARVESTDATE']
        for field in date_fields_to_reformat:
            transformer.format_date_field(field, '%d-%b-%y', '%m/%d/%y')
            transformer.format_date_field(field, '%m-%d-%Y', '%m/%d/%y')

        # TF6
        # TODO: I am concerned about the meaning of this in the spec. -natalie
        log.debug("before constrain:")
        log.debug(','.join(self.data_frame.columns))
        transformer.constrain_field_value_length('TITER', 10, 'left')

        # TF7
        transformer.rename_field_name('SPECID', 'ALTERNATIVE_SPECID')

        # TF9
        # copy field (don't just replace)
        transformer.rename_field_name('INITDILUTION', 'CUTOFF', replace=False)
     
        # TF10

        # TODO NT:
        # short to long code
        # TODO: move to some shared location. transformations subpackage?
        formal_network_abbreviation = ''
        short_to_long_network_names = {
            'VTN' : 'HVTN',
            'PTN' : 'HPTN',
            'CVD' : 'CAVD'
        }
        if self.network in short_to_long_network_names:
            self.formal_network_abbreviation = short_to_long_network_names[self.network]
        else:
            formal_network_abbreviation = self.network

        fields_to_add = {
            'NETWORK': formal_network_abbreviation,
            'PROTOCOL': self.protocol,
            'LABID': self.lab_id,
            'ASSAYRUN': 'Y',
            'INFUNITS': '',
            'RELIABLE': 'Y',
            'REPLACE': 'N',
            'MODDT': '',
            'MOI': '',
            'WELLGROUP': '',
            'COHORT': '',
            'COMMENTS': ''
        }
        for new_field_name, new_field_value in fields_to_add.iteritems():
            transformer.add_new_field(new_field_name, new_field_value)

        # TF11
        # TODO unicode- natalie: update unicode transformation function
        #transformer.replace_unicode_value_in_field('BACKBONE', u"\u0394", 'D')
        self.data_frame['BACKBONE'] = self.data_frame.apply(lambda row: re.sub('\xCE\x94', 'D', row['BACKBONE']), axis=1)

        # TF12
        transformer.rename_field_name('METHOD', 'ASSAY_METHOD')

        # TF13
        transformer.rename_field_name('FILENAME', 'INSTRUMENT_FILENAME')

        # TF8
        for field in list(self.data_frame.columns):
            transformer.down_case_field_name(field)

    def check_data_after_transformations(self):
        return False

    def _fill_empty_values_in_isolate_field_with_virusnameother(self):
        self.data_frame['ISOLATE'].fillna(self.data_frame['VIRUSNAMEOTHER'], inplace=True)
        
        # TODO, fix
        self.data_frame['ISOLATE'] = self.data_frame.apply(lambda row: row['VIRUSNAMEOTHER'] if row['ISOLATE'] == '' else row['ISOLATE'], axis=1)

    def _melt_titrate_fields(self):
        log.debug("in melt:")
        log.debug(','.join(self.data_frame.columns))
        data_fields = list(self.data_frame.columns)
        value_fields = ['TITER_50', 'TITER_80']

        id_fields = [x for x in data_fields if x not in value_fields]    
        
        self.data_frame = pd.melt(
            self.data_frame,
            id_vars=id_fields,
            value_vars=value_fields,
            var_name='POSCRIT',
            value_name='TITER')

        log.debug("after melt:")
        log.debug(','.join(self.data_frame.columns))

    def _parse_poscrit_field(self):
        # TODO: move to transformations?
        self.data_frame['POSCRIT'] = self.data_frame['POSCRIT'].apply(lambda x: x.split('_')[1])

    # Define class variables here:
    field_separator = '\t'

    expected_input_fields = [
        'PROTNUM',
        'ASSAYID',
        'SPECID',
        'PTID',
        'VISITNO',
        'DRAWDT',
        'ASSAYTYP',
        'CELLTYPE',
        'ISOLATE',
        'POSCRIT_1',
        'POSCRIT_2',
        'TITER_50',
        'TITER_80',
        'TESTDT',
        'HOSTCELL',
        'BACKBONE',
        'INTERPRETMETHOD',
        'VIRUSTYPE',
        'VIRUSDILUTION',
        'CONCENTRATION_UNITS',
        'METHOD',
        'HARVESTDATE',
        'VIRUSID',
        'INCUBATION',
        'EXPERIMENTER',
        'PLATENUM',
        'MABLOT',
        'INITDILUTION',
        'DILUTIONFACTOR',
        'FILENAME',
        'CURVEIC50OORINDICATOR',
        'CURVEIC80OORINDICATOR',
        'RUNGROUP',
        'RUN_ROWID',
        'VIRUSNAMEOTHER',
        'RESULT_ROWID'
    ]

#-----------------------------------------------------------------------------#


# TODO: fix
# class TestFillEmptyValuesInIsolateFieldWithVirusnameother:
#     def test_fill_values(self):
#         df = DataFrameTransformations(pd.DataFrame({
#             'isolate': ['a', np.nan, 'b'],
#             'virusnameother': ['s', 's', 's']}))
#         df.fill_empty_values_in_isolate_field_with_virusnameother()
#         expected_df = pd.DataFrame({
#             'isolate': ['a', 's', 'b'],
#             'virusnameother': ['s', 's', 's']})
#         assert_frame_equal(df.data_frame, expected_df)

# TODO: fix
# class TestMeltTitrateFields:
#     def test_melt(self):
#         df = pd.DataFrame({
#             'other': ['a', 'b'], 
#             'titer_50': [1, 2], 
#             'titer_80': [3, 4]})
#         df = DataFrameTransformations(df)
#         df.melt_titrate_fields()
#         expected_df = pd.DataFrame({
#             'other': ['a', 'b', 'a', 'b'], 
#             'titer': ['titer_50', 'titer_50', 'titer_80', 'titer_80'], 
#             'poscrit': [1, 2, 3, 4]})
#         assert_frame_equal(
#             df.data_frame.sort_index(axis=1), 
#             expected_df.sort_index(axis=1))

class TestParseFilename:
        
    def test_parse_filename_with_good_input(self):
        filename = 'VTN704_AIDNABDU20190104001_A.tsv'
      
        file_parser = LDXNAB001LabDataFile()
        
        file_parser.setup_input_from_filename(filename)

        extracted_data = [file_parser.network, file_parser.protocol, file_parser.assay_code, file_parser.lab_id, \
file_parser.year_number, file_parser.month_number, file_parser.day_number, file_parser.file_sequence_number, file_parser.file_version_code]
        
        expected_data = \
        ['VTN','704','AIDNAB','DU', '2019','01','04','001', 'A']


        assert expected_data == extracted_data


    def test_parse_filename_with_good_input_delete(self):
        filename = 'VTN704_AIDNABDU20190104001_DELETE.tsv'
      
        file_parser = LDXNAB001LabDataFile()
        
        file_parser.setup_input_from_filename(filename)

        extracted_data = [file_parser.network, file_parser.protocol, file_parser.assay_code, file_parser.lab_id, \
file_parser.year_number, file_parser.month_number, file_parser.day_number, file_parser.file_sequence_number, file_parser.file_version_code]
        
        expected_data = \
        ['VTN','704','AIDNAB','DU', '2019','01','04','001', 'DELETE']


        assert expected_data == extracted_data

    def test_parse_filename_with_bad_input(self):
        filename = 'VTN04_AIDNABDU20190104001_A.tsv'
      
        file_parser = LDXNAB001LabDataFile()
        
        assert file_parser.setup_input_from_filename(filename) == False



class TestReadFile:
    def test_parse_stream_with_good_structure(self):
        # create a string representation of a file, without regards to datatypes

        data = '\t'.join(LDXNAB001LabDataFile.expected_input_fields)
        data = data + '\t'.join(range(len(LDXNAB001LabDataFile.expected_input_fields)))
        parser = LDXNAB001LabDataFile()


        # TODO
        #strstream = StringIO.StringIO(data)
        #parser.read_tsv(strstream)

        #print parser.data_frame.head()
        assert False


    def test_parse_stream_with_bad_tsv_format(self):
        assert False

    def test_parse_stream_with_too_many_columns(self):
        assert False

    def test_parse_stream_with_too_few_columns(self):
        assert False


def main():
    # do some tests
    log.debug("testing lab data file")
    lab_data_file = LDXNAB001LabDataFile()

    test_filename = '/trials/LabDataOps/assay_information/NAB-LDOGEN-50-DEVEL/AIDNAB_DU_TEST_DATA.tsv'

    lab_data_file.set_filename(test_filename)
    lab_data_file.read_file()
    lab_data_file.transform_data()

    print lab_data_file.data_frame.head()

    log.debug("done testing lab data file")



if __name__ == '__main__':
    main()