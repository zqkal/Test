#!/usr/local/apps/python/python-controlled/bin/python -tt

""" Pipeline factory. """

import logging
log = logging.getLogger(__name__)
import sys

import imports
from ldxnab001 import LDXNAB001Pipeline
from ldxnab002 import LDXNAB002Pipeline
from ldxelisapk003 import LDXELISAPK003Pipeline

#-----------------------------------------------------------------------------#

class Pipelines:

    primaryKeyToPipelineClassName = {
        'HVTN703NAB' : 'ldxnab001',
        'HVTN704NAB' : 'ldxnab001',
        'HPTN081NAB' : 'ldxnab001',
        'HPTN085NAB' : 'ldxnab001',
        'CAVD733NAB' : 'ldxnab002',
        'CAVD739.01ELISAPK' : 'ldxelisapk003',
        'CAVD684ELISAPK' : 'ldxelisapk003',
        'CAVD583.01ELISAPK' : 'ldxelisapk003',
        'CAVD584.01ELISAPK' : 'ldxelisapk003',
        'CAVD583.02ELISAPK' : 'ldxelisapk003',
        'CAVD584.02ELISAPK' : 'ldxelisapk003'
    }

    def __init__(self):
        pass

    def get_pipeline(self, network, protocol, assay, lab_id):

        # TODO: add lab_id as a primary key?

        key_string = network + protocol + assay
        if key_string in Pipelines.primaryKeyToPipelineClassName:
            log.info("identified pipeline for {} {} {}!".format(network, protocol, assay))
            pipeline_code = Pipelines.primaryKeyToPipelineClassName[key_string]

            # TODO: generalize this so we dont need to defined this every time we make a new pipeline
            if pipeline_code == 'ldxnab001':
                log.info("initializing ldxnab001 pipeline")
                return LDXNAB001Pipeline(network, protocol, assay, lab_id)
            elif pipeline_code == 'ldxnab002':
                log.info("initializing ldxnab002 pipeline")
                return LDXNAB002Pipeline(network, protocol, assay, lab_id)
            elif pipeline_code == 'ldxelisapk003':
                log.info("initializing ldxelisapk003 pipeline")
                return LDXELISAPK003Pipeline(network, protocol, assay, lab_id)
            else:
                log.error("unimplemented pipeline (the pipeline requested using the internal code: {})".format(pipeline_code))

        log.error("unsupport network/protocol/assay: {} {} {}".format(network, protocol, assay))
        return None

       




