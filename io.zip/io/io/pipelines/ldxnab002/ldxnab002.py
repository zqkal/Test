#!/usr/local/apps/python/python-controlled/bin/python -tt

"""  Main LDXNAB002 control flow. """

import logging
logging.basicConfig(level=logging.DEBUG, format='%(asctime)s\t[%(levelname)s]\t%(message)s', datefmt='%d-%b-%y %H:%M:%S')
log = logging.getLogger(__name__)
import datetime
from glob import glob
import os
import pandas as pd
import re
import sys
import numpy as np
import pytest
from pandas.util.testing import assert_frame_equal # <-- for testing dataframes

import assay_report
from data_frame_transformations import DataFrameTransformations
from data_checks import DataFrameDataChecks
from ldxnab002_lab_data_file import LDXNAB002LabDataFile

#-----------------------------------------------------------------------------#

class LDXNAB002Pipeline:

    ordered_output_field_list = [
        'network',
        'protnum',
        'labid',
        'assayid',
        'specid',
        'ptid',
        'visitno',
        'visitday',
        'visit_modifier',
        'drawdt',
        'assaytyp',
        'assayrun',
        'celltype',
        'isolate',
        'infunits',
        'poscrit_1',
        'poscrit_2',
        'cutoff',
        'titer_50',
        'titer_80',
        'testdt',
        'reliable',
        'replace',
        'moddt',
        'comments',
        'hostcell',
        'backbone',
        'interpretmethod',
        'virustype',
        'virusdilution',
        'concentration_units',
        'curveic50orindicator',
        'curveic80orindicator',
        'method',
        'harvestdate',
        'virusid',
        'incubation',
        'experimenter',
        'platenum',
        'mablotnum',
        'initdilution',
        'dilutionfactor',
        'result_rowid',
        'virusnameother',
        'run_comments',
        'run_rowid',
        'filename'
    ]

    def __init__(self, network, protocol, assay, lab_id):
        self.network = network
        self.protocol = protocol
        self.assay = assay
        self.lab_id = lab_id
        self.lab_data_filename = ''
        self.output_data_path = ''
        self.lab_data_file = LDXNAB002LabDataFile()
        self.data_frame = pd.DataFrame()

    def setup(self, input_data_filename, output_data_path):
        """ Record the basics: i/o filenames """
        self.lab_data_filename = input_data_filename
        self.output_data_path = output_data_path
        self.lab_data_file.set_filename(self.lab_data_filename)

        if not self.lab_data_file.filename:
            # TODO log
            log.error('could not set lab data file to {}'.format(self.lab_data_filename))
            sys.exit(-1)

    def run(self):
        """ Orchestrate the pipeline. """
        
        self.read_input_files()

        # TODO: discuss checks, for later. OK for production.
        # self.check_input_data()

        self.data_transformations()

        self.data_checks()

        self.pre_output_transformations()

        self.generate_pipeline_output()

    def read_input_files(self):
        self.lab_data_file.read_file()
        self.data_frame = self.lab_data_file.data_frame

    def check_input_data(self):
        checks_result = self.lab_data_file.check_input_data()
        if not checks_result:
            log.error('Input lab data checks failed. Exiting program...')
            sys.exit(-1)

    def data_transformations(self):
        """ """
        transformer = DataFrameTransformations(self.data_frame)

        # TF-1
        transformer.down_case_field_names()

        # TF-2: Add new blank fields
        transformer.add_new_field('visit_modifier')
        transformer.add_new_field('infunits')
        transformer.add_new_field('moddt')
        transformer.add_new_field('assaytyp')
        transformer.add_new_field('comments')
        transformer.add_new_field('visitday')
        transformer.add_new_field('cutoff')

        # TF-3: Add new fields with default values
        transformer.add_new_field('network', field_value='CAVD')
        transformer.add_new_field('labid', field_value='MS')
        transformer.add_new_field('assayrun', field_value='Y')
        transformer.add_new_field('reliable', field_value='Y')
        transformer.add_new_field('replace', field_value='N')

        # kinda part of TF-3
        transformer.set_new_values_for_field('protnum', 'Pantaleo_733')

        # TF-5
        transformer.fill_blank_field_values_using_values_from_another_field('isolate', 'virusnameother')

        # TF-6
        transformer.replace_field_values('celltype', {'A3R5.7': 'A3R5'})
        transformer.replace_field_values('celltype', {'TZM-BL': 'TZM-bl'})
        transformer.replace_field_values('celltype', {'TZM.BL CELLS': 'TZM-bl'})

        # TF-7 TODO: method not working, fix
        # need to handle values HT92_Week26
        self._parse_specid_field()

        # TF-8
        transformer.rename_field_name('mablot', 'mablotnum')

        # TF-N # TODO (MW) update specs for unicode fix)
        # TODO (NT): update unicode transformation class function
        #transformer.replace_unicode_value_in_field('backbone', u"\u0394", 'D')
        self.data_frame['backbone'] = self.data_frame.apply(lambda row: re.sub('\xCE\x94', 'D', row['backbone']), axis=1)

    def _parse_specid_field(self):
        """ Split the specid value into the field ptid, visitno and visit_modifier

        TODO (MW): debug, unit tests are failing, update method!!!

        Note: Added new fields to self. If new fields already in dataframe, logs
            warning and overwrites the field. TODO (NT): approve implimentation choice
        Example:
        SPECID          Final PTID  Final VISITNO   Final VISIT_MODIFIER
        IC47_Week 6     IC47        6               Week
        IC47_Week6      IC47        6               Week

        Raises:
            KeyError: is field 'specid' missing from DataFrame
            ValueError: if field value parsing results in inappropriately split values.
        """

        if 'visitno' in self.data_frame:
                log.info('rewriting field visitno using extracted values from original specid field')
        if 'visit_modifier' in self.data_frame:
                log.info('rewriting field visit_modifier using extracted values from original specid field')
        if 'specid' not in self.data_frame:
            raise KeyError('specid field missing from DataFrame')

        # check that specc id values are parsable
        for index, row in self.data_frame.iterrows():
            # TODO: replace with regex?
            string_to_parse = row['specid']

            ptid_pattern = r'([^_]+)'
            date_unittype_pattern = r'([a-zA-Z]+)'
            date_number_pattern = r'([0-9]+)'

            specid_parse_pattern = ptid_pattern + r'_' + date_unittype_pattern + r'\s*' + date_number_pattern

            #log.debug('using specid parse regex {}'.format(specid_parse_pattern))

            specid_parse_match = re.search(specid_parse_pattern, string_to_parse)

            if not specid_parse_match:
                err_msg = 'specid value not parsable: {}'.format(string_to_parse)
                log.error(err_msg)
                raise ValueError(err_msg)
            else:
                parsed_ptid = specid_parse_match.group(1)
                parsed_date_unit_type = specid_parse_match.group(2)

                # TODO try/catch the int cast
                parsed_date_number_value = str(int(specid_parse_match.group(3)))

                # log.debug('parsed {}, {}, {}'.format(parsed_ptid, parsed_date_unit_type, parsed_date_number_value))
                self.data_frame['ptid'][index] = parsed_ptid
                self.data_frame['visitno'][index] = parsed_date_number_value
                self.data_frame['visit_modifier'][index] = parsed_date_unit_type


    def data_checks(self):
        data_checker = DataFrameDataChecks(self.data_frame)

        # having false value will trigger cumulative check failure
        check_result_list = []

        fields_that_must_not_contain_blank_values = ['ptid', 'visitno', 'drawdt']
        log.info('checking that fields must not contain blank values for fields {}'.format(','.join(fields_that_must_not_contain_blank_values)))

        for field in fields_that_must_not_contain_blank_values:
            check_result_list.append(data_checker.are_field_values_not_blank(field))

        primary_key_list = [
            'protnum', 'labid', 'ptid', 'visitno', 'assaytyp', 'celltype', 'isolate',
            'poscrit_1', 'poscrit_2', 'cutoff', 'hostcell', 'virustype'
            ]
        log.info('checking that all rows are unique, keyed on the following fields: {}'.format(','.join(primary_key_list)))
        check_result_list.append(data_checker.are_all_rows_primary_key_unique(primary_key_list))

        if not all(check_result_list):
            log.error('Data checks failed!')
            sys.exit(-1)
            # TODO: gather the result and log !!! data check failure but producing with output, do not send data to stats'
        else:
            log.info('all data checks passed')

    def pre_output_transformations(self):
        # TF-9
        self._order_and_select_fields(self.ordered_output_field_list)

    def _order_and_select_fields(self, ordered_output_field_list):
        """ Select a subset of fields, reorder, and discard the rest

        Note: reassigns self.DataFrame
        TODO (NT): move into Transformations after reference/copy worked out
        
        Args:
            ordered_output_field_list (list): ordered field names.
        Raises:
            KeyError: If any field in ordered_output_field_list is missing from DataFrame
        """
        for field in ordered_output_field_list:
            if field not in self.data_frame:
                raise KeyError('{} field missing from DataFrame'.format(field))
        self.data_frame = self.data_frame[ordered_output_field_list]

    def generate_pipeline_output(self):
        
       
        # TODO: try to make this more generic code?
      
        # TODO: label file as DRAFT if any checks fail

        datestring = str(datetime.date.today()).replace('-', '')

        short_network_abbreviation = ''
        long_to_short_network_names = {
            'HVTN' : 'VTN',
            'HPTN' : 'PTN',
            'CAVD' : 'CVD'
        }

        if self.network in long_to_short_network_names:
            short_network_abbreviation = long_to_short_network_names[self.network]
        else:
            short_network_abbreviation = self.network

        log.debug('given network abbr: ' + self.network)
        log.debug('shortened network abbr:' + short_network_abbreviation)

        # CVD_NAB_<LAB_ID>_<date_YYYYMMDD>.txt        
        output_pattern = '{}_NAB_{}_{}.txt'.format(short_network_abbreviation, self.lab_id, datestring)


        # TODO (nt, optional, later) - increment output filename if there is previous output from same day

        output_fullpath = os.path.join(self.output_data_path, output_pattern)
        log.info('writing preprocessor output to {}'.format(output_fullpath))
        self.data_frame.to_csv(output_fullpath, sep='\t', index=False)

        # generate a summary report
        summary_filename = '{}_summary_report.xlsx'.format(output_pattern.strip('.txt'))
        summary_fullpath = os.path.join(self.output_data_path, summary_filename)
        assay_report.make_assay_report(self.data_frame, 'ldxnab002', summary_fullpath)
        log.info('writing summary report output to {}'.format(summary_fullpath))

        # TODO: "done!" message -- also include summary of what files were output, and where

#-----------------------------------------------------------------------------#
# Unit tests for pipeline specific transformations TODO: Move?

class TestOrderAndSelectFields:

    def test_orders_fields(self):
        pipeline = LDXNAB002Pipeline('CAVD', '733', 'NAB', 'XX')
        pipeline.data_frame = pd.DataFrame(columns=['C', 'A', 'B'])
        expected_df = pd.DataFrame(columns=['A', 'B', 'C'])
        pipeline._order_and_select_fields(['A', 'B', 'C'])
        assert_frame_equal(
            pipeline.data_frame.sort_index(axis=1), 
            expected_df.sort_index(axis=1))

    def test_keeps_select_fields(self):
        pipeline = LDXNAB002Pipeline('CAVD', '733', 'NAB', 'XX')
        pipeline.data_frame = pd.DataFrame(columns=['C', 'A', 'B'])
        expected_df = pd.DataFrame(columns=['C', 'B'])
        pipeline._order_and_select_fields(['C', 'B'])
        assert_frame_equal(
            pipeline.data_frame.sort_index(axis=1), 
            expected_df.sort_index(axis=1))

    def test_raise_key_error_for_missing_field(self):
        pipeline = LDXNAB002Pipeline('CAVD', '733', 'NAB', 'XX')
        with pytest.raises(KeyError):
            pipeline._order_and_select_fields(['field_name'])


class TestParseSpecidField:
    def test_splits_specid_correctly(self):
        pipeline = LDXNAB002Pipeline('CAVD', '733', 'NAB', 'MS')
        df = pd.DataFrame({
            'specid': ['IC47_Week 6', 'HT92_Day 0', 'RGw11_Week26'],
            'ptid': [np.nan, np.nan, np.nan], 
            'visit_modifier': [np.nan, np.nan, np.nan],
            'visitno': ['', '', ''] # note, these become floats in the test if initialized as np.nan
            })
        pipeline.data_frame = df
        expected_df = pd.DataFrame({
            'specid': ['IC47_Week 6', 'HT92_Day 0', 'RGw11_Week26'],
            'ptid': ['IC47', 'HT92', 'RGw11'], 
            'visit_modifier': ['Week', 'Day', 'Week'],
            'visitno': ['6', '0', '26']
            })
        pipeline._parse_specid_field()
        assert_frame_equal(pipeline.data_frame, expected_df, check_dtype=False)

    def test_raise_value_error_for_non_parsable_field_value(self):
        pipeline = LDXNAB002Pipeline('CAVD', '733', 'NAB', 'MS')
        df = pd.DataFrame({'specid': ['no underscore', 'no_blank_space']})
        pipeline.data_frame = df
        with pytest.raises(ValueError):
            pipeline._parse_specid_field()

    def test_raise_key_error_for_missing_specid_field(self):
        pipeline = LDXNAB002Pipeline('CAVD', '733', 'NAB', 'MS')
        with pytest.raises(KeyError):
            pipeline._parse_specid_field()
