#!/usr/local/apps/python/python-controlled/bin/python -tt
# -*- coding: utf-8 -*-
""" Main object for reading in the Lab Data file """

import logging
logging.basicConfig(level=logging.DEBUG, format='%(asctime)s\t[%(levelname)s]\t%(message)s', datefmt='%d-%b-%y %H:%M:%S')
log = logging.getLogger(__name__)

import numpy as np
import pandas as pd
import pytest
import re
import StringIO
import sys

# TODO: figure out how to get this working
# so that this file can be run for it's main() test
#sys.path.append('/scharp/devel/ldx/io/io')
import imports
from data_frame_transformations import DataFrameTransformations
from data_checks import DataFrameDataChecks

#-----------------------------------------------------------------------------#

# TODO: NT and MW check in about moving I/O to module. Could add error checking 
# directly to methods or add a range of distinct pre-checks.
class LDXNAB002LabDataFile:

    # eventual goal: think about these in a support config file?
    field_separator = '\t'

    expected_input_fields = [
        ''
    ]

    def __init__(self):
        self.data_frame = pd.DataFrame()
        self.filename = ''
        self.network = ''
        self.protocol = ''
        self.assay_code = ''
        self.lab_id = ''
      
    def set_filename(self, filename):
        # TODO split path and save directory too
        # TODO ensure file exists
    
        self.filename = filename

        # if not self.parse_filename():
        #     # error
        #     return False
        # else:
        #     return True

    # TODO NT: make this parse a stream for testing purposes
    # to allow a string stream or a filename
    # TODO: require headers
    # TODO: error check read_csv!

    def read_file(self, input_source=''):
        # TODO any error checking at all

        if input_source == '':
            input_source = self.filename

        self.data_frame = pd.read_csv(
            filepath_or_buffer = input_source, 
            sep = self.field_separator, 
            dtype = str, 
            na_values = np.nan, 
            keep_default_na=False, 
            header=0)

    def check_input_data(self):
        data_checker = DataFrameDataChecks(self.data_frame)
        cumulative_result = True
        
        # TODO: add any checks here, if check fails then update cumulative_result 
        # to False
        return cumulative_result

    def transform_data(self):
        transformer = DataFrameTransformations(self.data_frame)

        # TODO: break into subfunctions, if desired
        # refer to ldxnab001, if desired

    def check_data_after_transformations(self):
        return False

#-----------------------------------------------------------------------------#

class TestReadFile:
    def test_parse_stream_with_good_structure(self):
        # create a string representation of a file, without regards to datatypes

        data = '\t'.join(LDXNAB002LabDataFile.expected_input_fields)
        data = data + '\t'.join(range(len(LDXNAB002LabDataFile.expected_input_fields)))
        parser = LDXNAB002LabDataFile()

        # TODO
        #strstream = StringIO.StringIO(data)
        #parser.read_tsv(strstream)

        #print parser.data_frame.head()
        assert False

    def test_parse_stream_with_bad_tsv_format(self):
        assert False

    def test_parse_stream_with_too_many_columns(self):
        assert False

    def test_parse_stream_with_too_few_columns(self):
        assert False


def main():
    # do some tests
    log.debug("testing LDXNAB002 lab data file")
    lab_data_file = LDXNAB002LabDataFile()

    test_filename = '' 

    lab_data_file.set_filename(test_filename)
    lab_data_file.read_file()
    lab_data_file.transform_data()

    print lab_data_file.data_frame.head()

    log.debug("done testing LDXNAB002 lab data file")


if __name__ == '__main__':
    main()