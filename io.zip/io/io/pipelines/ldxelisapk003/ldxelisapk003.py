#!/usr/local/apps/python/python-controlled/bin/python -tt

"""  Main LDXNAB002 control flow. """

import logging
logging.basicConfig(level=logging.DEBUG, format='%(asctime)s\t[%(levelname)s]\t%(message)s', datefmt='%d-%b-%y %H:%M:%S')
log = logging.getLogger(__name__)
import datetime
from glob import glob
import os
import pandas as pd
import re
import sys
import numpy as np
import pytest
from pandas.util.testing import assert_frame_equal # <-- for testing dataframes

# TODO: figure out how to get this working
# TODO: comment out before production push
# so that this file can be run for it's main() test
sys.path.append('/scharp/devel/ntasman/io_cavd_elisa_pk/io')


import imports

# TODO: Update PATHS for CAP production
# sys.path.append('/trials/LabDataOps/managed_code/consolidated_assay_preprocessor')
import assay_report
from data_frame_transformations import DataFrameTransformations
from data_checks import DataFrameDataChecks
from ldxelisapk003_lab_data_file import LDXELISAPK003LabDataFile

#-----------------------------------------------------------------------------#



# TODO NT
# Parse filename and test for consistency with commandline for protocol, network, and assay_method columns
# see accepted values checks for those fields as reference.


class LDXELISAPK003Pipeline:



    def __init__(self, network, protocol, assay, lab_id):
        self.network = network
        self.protocol = protocol
        self.assay = assay
        self.lab_id = lab_id
        self.lab_data_filename = ''
        self.output_data_path = ''
        self.lab_data_file = LDXELISAPK003LabDataFile()
        self.data_frame = pd.DataFrame()

    def setup(self, input_data_filename, output_data_path):
        """ Record the basics: i/o filenames """
        self.lab_data_filename = input_data_filename
        self.output_data_path = output_data_path
        self.lab_data_file.set_filename(self.lab_data_filename)

        if not self.lab_data_file.filename:
            # TODO log
            log.error('could not set lab data file to {}'.format(self.lab_data_filename))
            sys.exit(-1)

    def run(self):
        """ Orchestrate the pipeline. """
        
        self.read_input_files()

        self.check_untransformated_input_data()


        self.data_frame = self.lab_data_file.data_frame


        self.data_table_structure_transformations()

        self.data_table_structure_checks()


        self.data_content_transformations()

        self.data_content_checks()
        

        self.generate_pipeline_output()




        log.info("EXECUTION OK: CAVD ELISA pK data processing pipeline COMPLETE")


    def read_input_files(self):
        self.lab_data_file.read_file()
        


    # TODO NT:
    # move these log messages into the data checks!
    def check_untransformated_input_data(self):
        checks_result = self.lab_data_file.check_untransformed_input_data()
        if not checks_result:
            log.error('Data Structure Check FAIL:\tInput lab data file was missing column names. Exiting with error')
            sys.exit(-1)
        else:
            log.info('Data Structure Check OK:\tall input data column names verified')

    def data_table_structure_transformations(self):
        self._drop_input_data_table_columns()
        self._create_data_table_columns()
        self._rename_data_table_columns()
        

    def data_table_structure_checks(self):
        check_result = self._check_qdata_column_names()
        if not check_result:
            log.error('Data Structure Check FAIL:\tqdata output table is missing required columns. Exiting with error')
            sys.exit(-1)
        else:
            log.info('Data Structure Check OK:\tqdata output table contains all required columns')

    def data_content_transformations(self):
        """ """
        transformer = DataFrameTransformations(self.data_frame)

        # TF-DATA-01:
        # remove clonal identifier suffix in protocol

        self._remove_clonal_identifier_suffix_from_protocol()
        self._standarize_date_fields()
        self._downcase_fields()
        self._replace_field_contents_if_matched()
        self._standardize_capitalization_and_punctuation()
        self._add_content_for_new_fields()
        return
     



    def data_content_checks(self):
        data_checker = DataFrameDataChecks(self.data_frame)

        # ignore return codes; we don't error from these
        self._check_fields_are_not_blank()
        self._check_fields_are_conditionally_not_blank()

        self._check_values_are_in_expected_list()
        self._check_fields_are_numeric()

        self._check_date_values()
        self._check_numeric_values()

        return


        # having false value will trigger cumulative check failure
        # check_result_list = [True]


        # fields_that_must_not_contain_blank_values = ['ptid', 'visitno', 'drawdt']
        # log.info('checking that fields must not contain blank values for fields {}'.format(','.join(fields_that_must_not_contain_blank_values)))

        # for field in fields_that_must_not_contain_blank_values:
        #     check_result_list.append(data_checker.are_field_values_not_blank(field))


        # if not all(check_result_list):
        #     log.error('Data checks failed!')
        #     sys.exit(-1)
        #     # TODO: gather the result and log !!! data check failure but producing with output, do not send data to stats'
        # else:
        #     log.info('all data checks passed')



    def generate_pipeline_output(self):
        
       
        # TODO: try to make this more generic code?
      
        # TODO: label file as DRAFT if any checks fail

        datestring = str(datetime.date.today()).replace('-', '')

        short_network_abbreviation = ''
        long_to_short_network_names = {
            'HVTN' : 'VTN',
            'HPTN' : 'PTN',
            'CAVD' : 'CVD'
        }

        if self.network in long_to_short_network_names:
            short_network_abbreviation = long_to_short_network_names[self.network]
        else:
            short_network_abbreviation = self.network

        #log.debug('given network abbr: ' + self.network)
        #log.debug('shortened network abbr:' + short_network_abbreviation)

        # CVD_NAB_<LAB_ID>_<date_YYYYMMDD>.txt        
        output_pattern = '{}_ELISAPK_{}_{}.txt'.format(short_network_abbreviation, self.lab_id, datestring)


        # TODO (nt, optional, later) - increment output filename if there is previous output from same day

        output_fullpath = os.path.join(self.output_data_path, output_pattern)
        log.info('writing preprocessor output to {}'.format(output_fullpath))
        self.data_frame.to_csv(output_fullpath, sep='\t', index=False)

        # generate a summary report
        summary_filename = '{}_summary_report.xlsx'.format(output_pattern.strip('.txt'))
        summary_fullpath = os.path.join(self.output_data_path, summary_filename)
        assay_report.make_assay_report(self.data_frame, 'ldxelisapk003', summary_fullpath)
        log.info('writing summary report output to {}'.format(summary_fullpath))

        # TODO: "done!" message -- also include summary of what files were output, and where



# ---------- internal data and support functions --------------- #

    input_data_columns_to_drop = [
        'timepointbaseline',
        'sampledatereceived',
        'sampledateprocessed',
        'sourcefilelong',
        'sourcefileshort',
        'runid',
        'recordid',
        'assayid'
    ]

    def _drop_input_data_table_columns(self):
        data_transformer = DataFrameTransformations(self.data_frame)
        data_transformer.drop_fields(self.input_data_columns_to_drop)


    columns_to_create = [
        'source_file_name',
        'upload_date',
        'ldo_preprocessing_date'
    ]

    def _create_data_table_columns(self):
        data_transformer = DataFrameTransformations(self.data_frame)
        for field in self.columns_to_create:
            data_transformer.add_new_field(field, '')

    columns_to_rename = {
        'datasetcreationdate' : 'dataset_creation_date_lab',
        'datasetversion' : 'dataset_version_lab',
        'study' : 'protocol',
        'assayplatform' : 'assay_method',
        'assaydate' : 'experiment_date',
        'experimentid' : 'notebook',
        'description' : 'sample_description',
        'globalid' : 'sample_id',
        'sampleid' : 'subject_id',
        'visitid' : 'visit_description',
        'timepoint' : 'time_point',
        'timepointunits' : 'time_point_units',
        'samplingtimepoint' : 'sampling_time_point',
        'samplingtimepointunits' : 'sampling_time_point_units',
        'samplingtimepointreference' : 'sampling_time_point_reference',
        'samplingtimepointreferenceproduct' : 'sampling_time_point_detail',
        'sampletype' : 'spectype',
        'sampledatecollected' : 'sample_date_collected',
        'samplecontamination' : 'sample_comments',
        'samplespecies' : 'sample_species',
        'samplerole' : 'specrole',
        'valuesummary' : 'is_summary',
        'valuesummarytype' : 'summary_type',
        'valuesummarymethod' : 'summary_method',
        'opticaldensity' : 'od',
        'opticaldensitybackgroundsubtracted' : 'od_minus_background_lab',
        'opticaldensitybackgroundblanksubtracted' : 'od_minus_background_minus_blank_lab',
        'opticaldensitycurvelocation' : 'od_curve_location',
        'concentrationexpected' : 'concentration_expected',
        'concentrationobserved' : 'concentration_observed',
        'concentrationpercentrecovery' : 'concentration_percent_recovery',
        'concentrationoorflag' : 'concentration_oor',
        'concentrationunits' : 'concentration_units',
        'concentrationwellvalue' : 'concentration_uncorrected',
        'concentrationstandard' : 'concentration_standard',
        'concentrationmethod' : 'concentration_method',
        'linearrangemin' : 'linear_range_min',
        'linearrangemax' : 'linear_range_max',
        'linearrangeunits' : 'linear_range_units',
        'lowerlimitofdetection' : 'llod',
        'lowerlimitofdetectionunits' : 'llod_units',
        'lowerlimitofquantitation' : 'lloq',
        'lowerlimitofquantitationunits' : 'lloq_units',
        'upperlimitofdetection' : 'ulod',
        'upperlimitofdetectionunits' : 'ulod_units',
        'upperlimitofquantitation' : 'uloq',
        'upperlimitofquantitationunits' : 'uloq_units',
        'positivitycalculated' : 'is_positivity_calculated',
        'positivitystatus' : 'positivity_status',
        'positivitymethod' : 'positivity_method',
        'positivitythreshold' : 'positivity_threshold',
        'positivitythresholdmethod' : 'positivity_threshold_method',
        'positivityfoldchange' : 'positivity_fold_change',
        'positivitybaselinetimepoint' : 'positivity_baseline_timepoint',
        'coefficientofvariation' : 'cv',
        'coefficientofvariationsource' : 'cv_source',
        'coefficientofvariationtype' : 'cv_type',
        'standarddeviation' : 'sd',
        'standarddeviationsource' : 'sd_source',
        'standarddeviationtype' : 'sd_type',
        'well' : 'well_id',
        'plateid' : 'plate_id',
        'analysissoftware' : 'analysis_software',
        'readerserial' : 'instrument_serial',
        'titrationid' : 'titration_id',
        'concentrationstandardextinctioncoefficientsource' : 'extinction_coefficient_source'
    }

    def _rename_data_table_columns(self):
        data_transformer = DataFrameTransformations(self.data_frame)
        for original_name, new_name in self.columns_to_rename.iteritems():
            data_transformer.rename_field_name(original_name, new_name)

    required_qdata_columns = [
        'dataset_creation_date_lab',
        'dataset_version_lab',
        'labid',
        'network',
        'protocol',
        'assay_method',
        'experiment_date',
        'notebook',
        'isotype',
        'conjugate',
        'analyte',
        'sample_description',
        'sample_id',
        'subject_id',
        'visit_description',
        'time_point',
        'time_point_units',
        'sampling_time_point',
        'sampling_time_point_units',
        'sampling_time_point_reference',
        'sampling_time_point_detail',
        'spectype',
        'sample_date_collected',
        'sample_comments',
        'sample_species',
        'specrole',
        'dilution',
        'is_summary',
        'summary_type',
        'summary_method',
        'od',
        'od_minus_background_lab',
        'od_minus_background_minus_blank_lab',
        'od_curve_location',
        'concentration_expected',
        'concentration_observed',
        'concentration_percent_recovery',
        'concentration_oor',
        'concentration_units',
        'concentration_uncorrected',
        'concentration_standard',
        'concentration_method',
        'linear_range_min',
        'linear_range_max',
        'linear_range_units',
        'llod',
        'llod_units',
        'lloq',
        'lloq_units',
        'ulod',
        'ulod_units',
        'uloq',
        'uloq_units',
        'is_positivity_calculated',
        'positivity_status',
        'positivity_method',
        'positivity_threshold',
        'positivity_threshold_method',
        'positivity_fold_change',
        'positivity_baseline_timepoint',
        'exclude',
        'cv',
        'cv_source',
        'cv_type',
        'sd',
        'sd_source',
        'sd_type',
        'well_id',
        'plate_id',
        'analysis_software',
        'instrument_serial',
        'titration_id',
        'extinction_coefficient_source',
        'source_file_name',
        'upload_date',
        'ldo_preprocessing_date'
    ]

    def _check_qdata_column_names(self):
        data_checker = DataFrameDataChecks(self.data_frame)
        result = data_checker.are_all_fields_present(self.required_qdata_columns)
        return result

    # TODO unit test
    # OK nt - output verified
    def _remove_clonal_identifier_suffix_from_protocol(self):

        # for each protocol value,
        # replace trailing dot and numbers eg "739.01" -> "739"
        self.data_frame['protocol'] = self.data_frame.apply(lambda row: re.sub(r'\.[0-9]+', '', row['protocol']), axis=1)


    date_fields_to_standardize = [
        'dataset_creation_date_lab',
        'experiment_date',
        'sample_date_collected'
    ]
    # TODO unit test
    # OK nt - output verified. NOTE!! there is no input for assaydate in 684 test data!
    def _standarize_date_fields(self):
        transformer = DataFrameTransformations(self.data_frame)
        # TODO? check that fields are in qdata fields
        for field in self.date_fields_to_standardize:
            self.data_frame[field] = self.data_frame[field].apply(
            lambda s: s.strip())
            initial_date_format = r'%m/%d/%Y'
            desired_date_format = r'%d%b%Y' #ddMMMyyyy
            transformer.format_date_field(field, initial_date_format, desired_date_format)
            self.data_frame[field] = self.data_frame[field].apply(
            lambda s: s.upper())

    fields_to_downcase = [
        'time_point_units',
        'sampling_time_point_units',
        'sampling_time_point_reference',
        'spectype',
        'is_summary',
        'summary_type',
        'summary_method',
        'is_positivity_calculated',
        'positivity_status',
        'exclude'
    ]

    # TODO: unit check
    # OK nt - output verified
    def _downcase_fields(self):
        transformer = DataFrameTransformations(self.data_frame)
        
        # TODO? check that fields are in qdata fields?
        for field in self.fields_to_downcase:
            self.data_frame[field] = self.data_frame[field].apply(
            lambda s: s.lower())


    # OK nt - output verified for labid
    # OK nt - output verified for time_point_units
    # no data to test for sampling_time_point_units
    # no data to test for spectype
    # OK nt - output verified for positivity_status
    # no data to test for is_summary
    # OK nt - output verified for is_positivity_calculated
    # OK nt - output verified for exclude
    def _replace_field_contents_if_matched(self):
        transformer = DataFrameTransformations(self.data_frame)

        # fields to process:
        # labid, time_point_units, sampling_time_point_units, spectype, positivity_status, is_summary, is_positivity_calculated, exclude
        
        field_name = 'labid'
        replacement_dict = {'Tomaras' : 'GT'}
        case_sensitive = False
        ignore_punctuation = False
        match_if_contains = True
        transformer.replace_field_values(field_name, replacement_dict, case_sensitive, ignore_punctuation, match_if_contains)


        field_name = 'time_point_units'
        replacement_dict = {
            'week' : 'weeks',
            'day' : 'days',
            'minute' : 'minutes'
        }
        case_sensitive = False
        ignore_punctuation = False
        match_if_contains = True
        transformer.replace_field_values(field_name, replacement_dict, case_sensitive, ignore_punctuation, match_if_contains)


        field_name = 'sampling_time_point_units'
        replacement_dict = {
            'minutes' : 'minutes',
            'minute' : 'minutes',
            'mins' : 'minutes',
            'min' : 'minutes',
            'm' : 'minutes',
            'hours' : 'hours',
            'hour' : 'hours',
            'hrs' : 'hours',
            'hr' : 'hours',
            'h' : 'hours',
            'days' : 'days',
            'day' : 'days',
            'd' : 'days'
        }
        case_sensitive = False
        ignore_punctuation = False
        match_if_contains = True
        transformer.replace_field_values(field_name, replacement_dict, case_sensitive, ignore_punctuation, match_if_contains)

        
        field_name = 'spectype'
        replacement_dict = {
            'SER' : 'serum',
            'PLA' : 'plasma',
            'SAL' : 'salivia',
            'VWK' : 'vaginal weck',
            'REC' : 'rectal weck',
            'CVL' : 'cervical lavange',
            'SEM' : 'semen',
            'URN' : 'urine',
            'FEC' : 'fecal',
            'BIO-GUT' : 'biopsy-source',
            'VSPG' : 'vaginal sponge',
            'RSPG' : 'rectal sponge',
            'MAb' : 'monoclonal Ab',
            'PAb' : 'polyclonal Ab',
            'PSER' : 'pooled serum',
            'PPLA' : 'pooled plasma'
        }
        case_sensitive = False
        ignore_punctuation = False
        match_if_contains = True
        transformer.replace_field_values(field_name, replacement_dict, case_sensitive, ignore_punctuation, match_if_contains)

        
        
        field_name = 'positivity_status'
        replacement_dict = {
            'pos' : 'positive',
            'neg' : 'negative'
        }
        case_sensitive = False
        ignore_punctuation = False
        match_if_contains = True
        transformer.replace_field_values(field_name, replacement_dict, case_sensitive, ignore_punctuation, match_if_contains)

        

        field_name = 'is_summary'
        replacement_dict = {
            '0' : 'false',
            '1' : 'true'
        }
        case_sensitive = False
        ignore_punctuation = False
        match_if_contains = True
        transformer.replace_field_values(field_name, replacement_dict, case_sensitive, ignore_punctuation, match_if_contains)


        field_name = 'is_positivity_calculated'
        replacement_dict = {
            '0' : 'false',
            '1' : 'true'
        }
        case_sensitive = False
        ignore_punctuation = False
        match_if_contains = True
        transformer.replace_field_values(field_name, replacement_dict, case_sensitive, ignore_punctuation, match_if_contains)


        field_name = 'exclude'
        replacement_dict = {
            '0' : 'false',
            '1' : 'true'
        }
        case_sensitive = False
        ignore_punctuation = False
        match_if_contains = True
        transformer.replace_field_values(field_name, replacement_dict, case_sensitive, ignore_punctuation, match_if_contains)






    # TODO: make a second transformation function or adjust function signature to not need this
    def _list_to_double_dict(self, input_list):
        result = {}
        for field in input_list:
            result[field] = field

        return result



    # OK nt - output verified for




    # assay_method: no data to test
    # isotype: no data to test
    # conjugate: no data to test
    # sampling_time_point_reference: no data to test
    # summary_type: no data to test
    # od_curve_location: no data to test
    # concentration_oor: no data to test
    # concentration_units: no data to test
    # cv_source
    # cv_type
    # sd_source
    # sd_type
    # analysis_software
    # extinction_coefficient_source
    # concentration_method
    # linear_range_units
    # llod_units
    # lloq_units
    # ulod_units
    # uloq_units
    # positivity_method- TODO!! consult with Lab if need be
    def _standardize_capitalization_and_punctuation(self):

        transformer = DataFrameTransformations(self.data_frame)

        # fields to process:

        # assay_method
        # isotype
        # conjugate
        # sampling_time_point_reference
        # summary_type
        # od_curve_location
        # concentration_oor
        # concentration_units
        # cv_source
        # cv_type
        # sd_source
        # sd_type
        # analysis_software
        # extinction_coefficient_source
        # concentration_method
        # linear_range_units
        # llod_units
        # lloq_units
        # ulod_units
        # uloq_units
        # positivity_method - TODO!! consult with Lab if need be


        field_name = 'assay_method'
        replacement_dict = {
            'BAMA' : 'BAMA',
            'BAMA_AI' : 'BAMA_AI',
            'BAMA_TotalAb' : 'BAMA_TotalAb',
            'BAMA_3D' : 'BAMA_3D',
            'ELISA' : 'ELISA',
            'ELISA_TotalAb' : 'ELISA_TotalAb',
            'BLI' : 'BLI',
            'MicroArray' : 'MicroArray',
            'ADCP' : 'ADCP'
        }
        case_sensitive = False
        ignore_punctuation = True
        match_if_contains = False
        transformer.replace_field_values(field_name, replacement_dict, case_sensitive, ignore_punctuation, match_if_contains)


        field_name = 'isotype'
        replacement_dict = {
            'IgG' : 'IgG',
            'IgG1' : 'IgG1',
            'IgG2' : 'IgG2',
            'IgG3' : 'IgG3',
            'IgG4' : 'IgG4',
            'IgA' : 'IgA',
            'dIgA' : 'dIgA',
            'IgM' : 'IgM'
        }
        transformer.replace_field_values(field_name, replacement_dict, case_sensitive, ignore_punctuation, match_if_contains)

        
        field_name = 'conjugate'
        replacement_dict = {
            'Streptavidin' : 'Streptavidin',
            'IgG-PE' : 'IgG-PE',
             'Anti-Hu Fc' : 'Anti-Hu Fc',
             'Anti-Hu Kappa' : 'Anti-Hu Kappa'
        }
        transformer.replace_field_values(field_name, replacement_dict, case_sensitive, ignore_punctuation, match_if_contains)


        field_name = 'sampling_time_point_reference'
        replacement_dict = self._list_to_double_dict([
                'post-infusion',
                'pre-infusion',
                'base',
                'Base',
                'pre',
                'Pre',
                'post',
                'Post',
                'start',
                'Start',
                'end',
                'End'
            ])
        transformer.replace_field_values(field_name, replacement_dict, case_sensitive, ignore_punctuation, match_if_contains)


        field_name = 'summary_type'
        replacement_dict = self._list_to_double_dict([
                'inter-assay',
                'intra-assay'
            ])
        transformer.replace_field_values(field_name, replacement_dict, case_sensitive, ignore_punctuation, match_if_contains)


        field_name = 'od_curve_location'
        replacement_dict = self._list_to_double_dict([
                '>LR',
                '<LR',
                '<LLOD',
                '<LLOQ',
                '>ULOD',
                '>ULOQ',
                'OOR',
                'LR',
                '<LOD'
            ])
        transformer.replace_field_values(field_name, replacement_dict, case_sensitive, ignore_punctuation, match_if_contains)


        field_name = 'concentration_oor'
        replacement_dict = self._list_to_double_dict([
                '***',
                '?',
                '<',
                '<<',
                '>',
                '>>'
            ])
        transformer.replace_field_values(field_name, replacement_dict, case_sensitive, ignore_punctuation, match_if_contains)


        field_name = 'concentration_units'
        replacement_dict = self._list_to_double_dict([
            'ng/mL'
        ])
        transformer.replace_field_values(field_name, replacement_dict, case_sensitive, ignore_punctuation, match_if_contains)



        field_name = 'cv_source'
        replacement_dict = self._list_to_double_dict([
            'OD',
            'FI',
            'ObsConc',
            'OD-Bkgd'
        ])
        transformer.replace_field_values(field_name, replacement_dict, case_sensitive, ignore_punctuation, match_if_contains)



        field_name = 'cv_type'
        replacement_dict = self._list_to_double_dict([
            'inter-assay',
            'intra-assay'
        ])
        transformer.replace_field_values(field_name, replacement_dict, case_sensitive, ignore_punctuation, match_if_contains)


        field_name = 'sd_source'
        replacement_dict = self._list_to_double_dict([
            'OD',
            'FI',
            'ObsConc',
            'OD-Bkgd'
        ])
        transformer.replace_field_values(field_name, replacement_dict, case_sensitive, ignore_punctuation, match_if_contains)


        field_name = 'sd_type'
        replacement_dict = self._list_to_double_dict([
            'inter-assay',
            'intra-assay'
        ])
        transformer.replace_field_values(field_name, replacement_dict, case_sensitive, ignore_punctuation, match_if_contains)


        field_name = 'analysis_software'
        replacement_dict = self._list_to_double_dict([
            'Bioplex',
            'SoftmaxPro'
        ])
        transformer.replace_field_values(field_name, replacement_dict, case_sensitive, ignore_punctuation, match_if_contains)


        field_name = 'extinction_coefficient_source'
        replacement_dict = self._list_to_double_dict([
            'IgG Standard',
            'Manufacturer',
            'standard IgG coefficient',
            'manufacturer IgG coefficient'
        ])
        transformer.replace_field_values(field_name, replacement_dict, case_sensitive, ignore_punctuation, match_if_contains)


        field_name = 'concentration_method'
        replacement_dict = self._list_to_double_dict([
            'Bioplex 5pl'
        ])
        transformer.replace_field_values(field_name, replacement_dict, case_sensitive, ignore_punctuation, match_if_contains)


        field_name = 'linear_range_units'
        replacement_dict = self._list_to_double_dict([
            'OD',
            'ng/mL',
            'FI',
            'OD-Bkgd-Blank'
        ])
        transformer.replace_field_values(field_name, replacement_dict, case_sensitive, ignore_punctuation, match_if_contains)


        field_name = 'llod_units'
        replacement_dict = self._list_to_double_dict([
            'OD',
            'FI',
            'ng/mL'
        ])
        transformer.replace_field_values(field_name, replacement_dict, case_sensitive, ignore_punctuation, match_if_contains)


        field_name = 'lloq_units'
        replacement_dict = self._list_to_double_dict([
             'ng/mL'           
        ])
        transformer.replace_field_values(field_name, replacement_dict, case_sensitive, ignore_punctuation, match_if_contains)


        field_name = 'ulod_units'
        replacement_dict = self._list_to_double_dict([
            'OD',
            'FI',
            'ng/mL'
        ])
        transformer.replace_field_values(field_name, replacement_dict, case_sensitive, ignore_punctuation, match_if_contains)



        field_name = 'uloq_units'
        replacement_dict = self._list_to_double_dict([
             'ng/mL' 
        ])
        transformer.replace_field_values(field_name, replacement_dict, case_sensitive, ignore_punctuation, match_if_contains)


        field_name = 'positivity_method'
        replacement_dict = self._list_to_double_dict([
            'ULOD',
            'ULOQ',
            'OD',
            'LLOQ',
            'LLOD'
        ])
        transformer.replace_field_values(field_name, replacement_dict, case_sensitive, ignore_punctuation, match_if_contains)



        return


    def _add_content_for_new_fields(self):
        # 'source_file_name',
        # 'upload_date',
        # 'ldo_preprocessing_date'
        

        source_file_name = self.lab_data_filename
        self.data_frame['source_file_name'] = os.path.basename(source_file_name)


        upload_date_timestamp = os.path.getmtime(source_file_name)  # TODO file date
        upload_date = str(datetime.date.fromtimestamp(upload_date_timestamp))
        self.data_frame['upload_date'] = upload_date

        ldo_preprocessing_date = str(datetime.date.today()) # TODO today's date in correct format
        self.data_frame['ldo_preprocessing_date'] = ldo_preprocessing_date




    # --------------- checks --------------------


    fields_required_to_have_values = [
        'dataset_creation_date_lab',
        'dataset_version_lab',
        'labid',
        'network',
        'protocol',
        'assay_method',
        'experiment_date',
        'notebook',
        'isotype',
        'conjugate',
        'analyte',
        'sample_description',
        'specrole',
        'dilution',
        'is_summary',
        'od_minus_background_lab',
        'od_minus_background_minus_blank_lab',
        'od_curve_location',
        'is_positivity_calculated',
        'exclude',
        'plate_id',
        'analysis_software',
        'instrument_serial'
    ]

    def _check_fields_are_not_blank(self):
        checker = DataFrameDataChecks(self.data_frame)

        for field_name in self.fields_required_to_have_values:
             checker.are_field_values_not_blank(field_name)



    # contents:
    # ['field_name_A', 'field_name_B', field_name_B_trigger_values]
    fields_that_should_not_be_blank_when_other_field_has_trigger_values = [
        ['subject_id', 'specrole', ['sample'] ],
        ['visit_description', 'specrole', ['sample'] ],
        ['time_point', 'specrole', ['sample'] ],
        ['time_point_units', 'specrole', ['sample'] ],
        ['sample_species', 'specrole', ['sample'] ],
        ['summary_type', 'is_summary', ['true', '1'] ],
        ['summary_method', 'is_summary', ['true', '1'] ]
    ]


    # ['field_name_A', 'field_name_B']
    fields_that_should_not_be_blank_when_other_field_has_any_value =[
        ['concentration_units', 'concentration_observed'], 
        ['concentration_uncorrected', 'concentration_observed'], 
        ['concentration_standard', 'concentration_observed'], 
        ['concentration_method', 'concentration_observed'], 
        ['linear_range_min', 'concentration_observed'], 
        ['linear_range_max', 'concentration_observed'], 
        ['linear_range_units', 'concentration_observed'], 
        ['llod', 'concentration_observed'], 
        ['llod_units', 'concentration_observed'], 
        ['lloq', 'concentration_observed'], 
        ['lloq_units', 'concentration_observed'], 
        ['ulod', 'concentration_observed'], 
        ['ulod_units', 'concentration_observed'], 
        ['uloq', 'concentration_observed'], 
        ['uloq_units', 'concentration_observed'], 

        ['positivity_status', 'is_positivity_calculated'],
        ['positivity_method', 'is_positivity_calculated'],
        ['positivity_threshold', 'is_positivity_calculated'],
        ['positivity_threshold_method', 'is_positivity_calculated'],
        ['positivity_fold_change', 'is_positivity_calculated'],
        ['positivity_baseline_timepoint', 'is_positivity_calculated'],

        ['cv_source', 'cv'],
        ['cv_type', 'cv'],

        ['sd_source', 'sd'],
        ['sd_type', 'sd']
    ]

    def _check_fields_are_conditionally_not_blank(self):
        checker = DataFrameDataChecks(self.data_frame)
        for check_info in self.fields_that_should_not_be_blank_when_other_field_has_trigger_values:
            field_name_A = check_info[0]
            field_name_B = check_info[1]
            field_B_trigger_value_set = check_info[2]

            #log.debug("a: {},  b: {}, b triggers: {}". format(field_name_A, field_name_B, ', '.join(field_B_trigger_value_set)))
            checker.does_field_A_have_content_if_field_B_contains_trigger_values(field_name_A, field_name_B, field_B_trigger_value_set)



        for check_info in self.fields_that_should_not_be_blank_when_other_field_has_any_value:
            field_name_A = check_info[0]
            field_name_B = check_info[1]

            checker.does_field_A_have_content_if_field_B_contains_any_values(field_name_A, field_name_B)





    # labid
    # isotype
    # conjugate
    # time_point_units
    # sampling_time_point_units
    # sampling_time_point_reference
    # spectype
    # specrole
    # is_summary
    # summary_type
    # summary_method
    # od_curve_location
    # concentration_oor
    # concentration_units
    # concentration_method
    # linear_range_units
    # llod_units
    # lloq_units
    # ulod_units
    # uloq_units
    # positivity_status
    # TODO !!!! positivity_method
    # exclude
    # cv_source
    # cv_type
    # sd_source
    # sd_type
    # analysis_software
    # extinction_coefficient_source
    def _check_values_are_in_expected_list(self):

        checker = DataFrameDataChecks(self.data_frame)

        # no need to capture return values;
        # requirements only call for warnings


        # in this implementation, we're separating the blank data check requirement as entirely separate checks
        ignore_blank_values = True





        field_name = 'protocol'

        protocol_long_name = 'Nussenzweig'
        protocol_non_clonal = re.sub(r'\.[0-9]+', '', self.protocol)
        protocol_long_name = protocol_long_name + ' ' + protocol_non_clonal
        accepted_values_list = [
            protocol_long_name
        ]
        checker.are_field_contents_in_list(field_name, accepted_values_list, ignore_blank_values)

        field_name = 'network'
        accepted_values_list = [
            self.network
        ]
        checker.are_field_contents_in_list(field_name, accepted_values_list, ignore_blank_values)


        field_name = 'assay_method'
        accepted_values_list = [
            'ELISA_PK'
        ]
        checker.are_field_contents_in_list(field_name, accepted_values_list, ignore_blank_values)



        field_name = 'labid'
        accepted_values_list = [
            'GT'
        ]
        checker.are_field_contents_in_list(field_name, accepted_values_list, ignore_blank_values)


        field_name = 'isotype'
        accepted_values_list = [
            'IgG',
            'IgG1',
            'IgG2',
            'IgG3',
            'IgG4',
            'IgA',
            'dIgA',
            'IgM'
        ]
        checker.are_field_contents_in_list(field_name, accepted_values_list, ignore_blank_values)


        field_name = 'conjugate'
        accepted_values_list = [
            'Streptavidin',
            'IgG-PE',
            'Anti-Hu Fc',
            'Anti-Hu Kappa'
        ]
        checker.are_field_contents_in_list(field_name, accepted_values_list, ignore_blank_values)



        field_name = 'time_point_units'
        accepted_values_list = [
            'weeks',
            'days',
            'minutes'
        ]
        checker.are_field_contents_in_list(field_name, accepted_values_list, ignore_blank_values)


        field_name = 'sampling_time_point_units'
        accepted_values_list = [
            'minutes',
            'hours',
            'days'
        ]
        checker.are_field_contents_in_list(field_name, accepted_values_list, ignore_blank_values)

        field_name = 'sampling_time_point_reference'
        accepted_values_list = [
            'post-infusion',
            'pre-infusion',
            'base',
            'Base',
            'pre',
            'Pre',
            'post',
            'Post',
            'start',
            'Start',
            'end',
            'End'
        ]
        checker.are_field_contents_in_list(field_name, accepted_values_list, ignore_blank_values)

        field_name = 'spectype'
        accepted_values_list = [
            'serum',
            'plasma',
            'salivia',
            'vaginal weck',
            'rectal weck',
            'cervical lavange',
            'semen',
            'urine',
            'fecal',
            'biopsy-source',
            'vaginal sponge',
            'rectal sponge',
            'monoclonal Ab',
            'polyclonal Ab',
            'pooled serum',
            'pooled plasma'
        ]
        checker.are_field_contents_in_list(field_name, accepted_values_list, ignore_blank_values)



        field_name = 'specrole'
        accepted_values_list = [
            'sample',
            'standard',
            'control',
            'background',
            'blank'
        ]
        checker.are_field_contents_in_list(field_name, accepted_values_list, ignore_blank_values)


        field_name = 'is_summary'
        accepted_values_list = [
            'false', 'true'
        ]
        checker.are_field_contents_in_list(field_name, accepted_values_list, ignore_blank_values)


        field_name = 'summary_type'
        accepted_values_list = [
            'inter-assay',
            'intra-assay'
        ]
        checker.are_field_contents_in_list(field_name, accepted_values_list, ignore_blank_values)


        field_name = 'summary_method'
        accepted_values_list = [
            'mean',
            'median'
        ]
        checker.are_field_contents_in_list(field_name, accepted_values_list, ignore_blank_values)




        field_name = 'od_curve_location'
        accepted_values_list = [
            '>LR',
            '<LR',
            '<LLOD',
            '<LLOQ',
            '>ULOD',
            '>ULOQ',
            'OOR',
            'LR',
            '<LOD'
        ]
        checker.are_field_contents_in_list(field_name, accepted_values_list, ignore_blank_values)

        field_name = 'concentration_oor'
        accepted_values_list = [
            '***',
            '?',
            '<',
            '<<',
            '>',
            '>>'
        ]
        checker.are_field_contents_in_list(field_name, accepted_values_list, ignore_blank_values)

        field_name = 'concentration_units'
        accepted_values_list = [
            'ng/mL'
        ]
        checker.are_field_contents_in_list(field_name, accepted_values_list, ignore_blank_values)

        field_name = 'concentration_method'
        accepted_values_list = [
            'Bioplex 5pl'
        ]
        checker.are_field_contents_in_list(field_name, accepted_values_list, ignore_blank_values)





        field_name = 'linear_range_units'
        accepted_values_list = [
            'OD',
            'ng/mL',
            'FI',
            'OD-Bkgd-Blank'
        ]
        checker.are_field_contents_in_list(field_name, accepted_values_list, ignore_blank_values)

        field_name = 'llod_units'
        accepted_values_list = [
            'OD',
            'FI',
            'ng/mL'
        ]
        checker.are_field_contents_in_list(field_name, accepted_values_list, ignore_blank_values)

        field_name = 'lloq_units'
        accepted_values_list = [
            'ng/mL'  
        ]
        checker.are_field_contents_in_list(field_name, accepted_values_list, ignore_blank_values)

        field_name = 'ulod_units'
        accepted_values_list = [
            'OD',
            'FI',
            'ng/mL'
        ]
        checker.are_field_contents_in_list(field_name, accepted_values_list, ignore_blank_values)

        field_name = 'uloq_units'
        accepted_values_list = [
             'ng/mL' 
        ]
        checker.are_field_contents_in_list(field_name, accepted_values_list, ignore_blank_values)

        field_name = 'positivity_status'
        accepted_values_list = [
            'positive',
            'negative'
        ]
        checker.are_field_contents_in_list(field_name, accepted_values_list, ignore_blank_values)



        field_name = 'exclude'
        accepted_values_list = [
            'false',
            'true'
        ]
        checker.are_field_contents_in_list(field_name, accepted_values_list, ignore_blank_values)

        field_name = 'cv_source'
        accepted_values_list = [
            'OD',
            'FI',
            'ObsConc',
            'OD-Bkgd'
        ]
        checker.are_field_contents_in_list(field_name, accepted_values_list, ignore_blank_values)

        field_name = 'cv_type'
        accepted_values_list = [
            'inter-assay',
            'intra-assay'
        ]
        checker.are_field_contents_in_list(field_name, accepted_values_list, ignore_blank_values)

        field_name = 'sd_source'
        accepted_values_list = [
            'OD',
            'FI',
            'ObsConc',
            'OD-Bkgd'
        ]
        checker.are_field_contents_in_list(field_name, accepted_values_list, ignore_blank_values)

        field_name = 'sd_type'
        accepted_values_list = [
            'inter-assay',
            'intra-assay'
        ]
        checker.are_field_contents_in_list(field_name, accepted_values_list, ignore_blank_values)

        field_name = 'analysis_software'
        accepted_values_list = [
            'Bioplex',
            'SoftmaxPro'
        ]
        checker.are_field_contents_in_list(field_name, accepted_values_list, ignore_blank_values)

        field_name = 'extinction_coefficient_source'
        accepted_values_list = [
            'IgG Standard',
            'Manufacturer',
            'standard IgG coefficient',
            'manufacturer IgG coefficient'
        ]
        checker.are_field_contents_in_list(field_name, accepted_values_list, ignore_blank_values)





        return


    # numeric_field_list_blanks_not_allowed = [

    # ]

    numeric_field_list_blanks_allowed = [
        'od',
        'concentration_expected',
        'concentration_observed',
        'concentration_percent_recovery',
        'cv',
        'sd',
        'time_point',
        'sampling_time_point',
        'dilution',
        'od_minus_background_lab',
        'od_minus_background_minus_blank_lab',
        'concentration_uncorrected',
        'linear_range_min',
        'linear_range_max',
        'llod',
        'lloq',
        'ulod',
        'uloq',
        'positivity_threshold',
        'positivity_fold_change'
    ]
   
    def _check_fields_are_numeric(self):
        checker = DataFrameDataChecks(self.data_frame)

        # for field_name in self.numeric_field_list_blanks_not_allowed:
        #     checker.is_field_numeric(field_name)
        

        # blank checks are done elsewhere for this pipeline
        for field_name in self.numeric_field_list_blanks_allowed:
            checker.is_field_numeric(field_name, ignore_blank_values=True)


    def _check_numeric_values(self):
        checker = DataFrameDataChecks(self.data_frame)

        checker.is_numeric_field_value_in_a_range_inclusive('concentration_percent_recovery', 0, 100, True, True)

        checker.is_numeric_field_value_gt_eq('od', 0, True, True)

        return False

    date_fields = [
        'dataset_creation_date_lab',
        'experiment_date',
        'sample_date_collected'
    ]
    def _check_date_values(self):
        date_format = r'%d%b%Y' #ddMMMyyyy
        today_date_string =  datetime.date.today().strftime(date_format)

        checker = DataFrameDataChecks(self.data_frame)

        for field_name in self.date_fields:
            checker.are_field_date_values_on_or_before_a_given_date(field_name, today_date_string, date_format, ignore_blank_values = True)

        
