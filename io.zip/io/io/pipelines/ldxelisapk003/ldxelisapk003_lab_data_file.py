#!/usr/local/apps/python/python-controlled/bin/python -tt
# -*- coding: utf-8 -*-
""" TODO: file header"""

import logging
logging.basicConfig(level=logging.DEBUG, format='%(asctime)s\t[%(levelname)s]\t%(message)s', datefmt='%d-%b-%y %H:%M:%S')
log = logging.getLogger(__name__)

import numpy as np
import pandas as pd
import pytest
import re
import StringIO
import sys

# TODO: figure out how to get this working
# so that this file can be run for it's main() test
#sys.path.append('/scharp/devel/ldx/io/io')
import imports
from data_frame_transformations import DataFrameTransformations
from data_checks import DataFrameDataChecks

#-----------------------------------------------------------------------------#

# TODO: NT and MW check in about moving I/O to mudule. Could add error checking 
# directly to methods or add a range of distinct pre-checks.
class LDXELISAPK003LabDataFile:

    # eventual goal: think about these in a support config file?
    field_separator = '\t'

    expected_input_fields = [
        ''
    ]

    def __init__(self):
        self.data_frame = pd.DataFrame()
        self.filename = ''
        self.network = ''
        self.protocol = ''
        self.assay_code = ''
        self.lab_id = ''
      
    def set_filename(self, filename):
        # TODO split path and save directory too
        # TODO ensure file exists
    
        self.filename = filename

        # if not self.parse_filename():
        #     # error
        #     return False
        # else:
        #     return True

    # TODO NT: make this parse a stream for testing purposes
    # to allow a string stream or a filename
    # TODO: require headers
    # TODO: error check read_csv!

    def read_file(self, input_source=''):
        # TODO any error checking at all

        if input_source == '':
            input_source = self.filename

        self.data_frame = pd.read_csv(
            filepath_or_buffer = input_source, 
            sep = self.field_separator, 
            dtype = str, 
            na_values = np.nan, 
            keep_default_na=False, 
            header=0)

        # Read in OK here!

    def check_untransformed_input_data(self):
        data_checker = DataFrameDataChecks(self.data_frame)


        # QC-STRUCTURE
        # input data table must have expected fields
        result = data_checker.are_all_fields_present(self.required_input_file_fields)

        return result
        


    def transform_data(self):
        transformer = DataFrameTransformations(self.data_frame)



    def check_data_after_transformations(self):
        return False


    required_input_file_fields = [
        'datasetcreationdate',
        'datasetversion',
        'labid',
        'network',
        'study',
        'assayplatform',
        'assaydate',
        'experimentid',
        'isotype',
        'conjugate',
        'analyte',
        'description',
        'globalid',
        'sampleid',
        'visitid',
        'timepoint',
        'timepointunits',
        'timepointbaseline',
        'samplingtimepoint',
        'samplingtimepointunits',
        'samplingtimepointreference',
        'samplingtimepointreferenceproduct',
        'sampletype',
        'sampledatecollected',
        'sampledatereceived',
        'sampledateprocessed',
        'samplecontamination',
        'samplespecies',
        'samplerole',
        'dilution',
        'valuesummary',
        'valuesummarytype',
        'valuesummarymethod',
        'opticaldensity',
        'opticaldensitybackgroundsubtracted',
        'opticaldensitybackgroundblanksubtracted',
        'opticaldensitycurvelocation',
        'concentrationexpected',
        'concentrationobserved',
        'concentrationpercentrecovery',
        'concentrationoorflag',
        'concentrationunits',
        'concentrationwellvalue',
        'concentrationstandard',
        'concentrationmethod',
        'linearrangemin',
        'linearrangemax',
        'linearrangeunits',
        'lowerlimitofdetection',
        'lowerlimitofdetectionunits',
        'lowerlimitofquantitation',
        'lowerlimitofquantitationunits',
        'upperlimitofdetection',
        'upperlimitofdetectionunits',
        'upperlimitofquantitation',
        'upperlimitofquantitationunits',
        'positivitycalculated',
        'positivitystatus',
        'positivitymethod',
        'positivitythreshold',
        'positivitythresholdmethod',
        'positivityfoldchange',
        'positivitybaselinetimepoint',
        'exclude',
        'coefficientofvariation',
        'coefficientofvariationsource',
        'coefficientofvariationtype',
        'standarddeviation',
        'standarddeviationsource',
        'standarddeviationtype',
        'well',
        'plateid',
        'sourcefilelong',
        'sourcefileshort',
        'analysissoftware',
        'readerserial',
        'runid',
        'recordid',
        'titrationid',
        'assayid',
        'concentrationstandardextinctioncoefficientsource'
    ]

