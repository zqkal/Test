#!/usr/local/apps/python/python-controlled/bin/python -tt
# -*- coding: utf-8 -*-

"""
    Module to hold DataFrameTransformations class containing DataFrame 
    transformation methods and unit tests.
"""

import logging
logging.basicConfig(level=logging.DEBUG, format='%(asctime)s\t[%(levelname)s]\t%(message)s', datefmt='%d-%b-%y %H:%M:%S')
log = logging.getLogger(__name__)

# import io_utils
import datetime
import numpy as np
import pandas as pd
import re

#-----------------------------------------------------------------------------#

class DataFrameTransformations:
    """This is a foundational class which should not depend on any other modules
    in this project. (*** expect maybe for datachecks?) It should be unaware of
    Pipeline objects.

    This class provides methods which manipulate a pandas dataframe.
    This class is instantiated with a dataframe to manipulate.
    All other information used in manipulations comes from parameters to these methods:
    either scalars, lists, or other pandas dataframe objects.
    """

    def __init__(self, data_frame_to_manipulate):
        self.data_frame = data_frame_to_manipulate

    # def order_and_select_fields(self, ordered_field_list):
    #     """ Order and select fields in the DataFrame.
    # TODO: not working!!!!, not updating DF
    #     Args:
    #         ordered_field_list (list): fields to retain in the dataset in order.
    #     Raises:
    #         KeyError: If any field in ordered_field_list is not found in DataFrame.
    #     """
    #     # TODO: test this
    #     for field in ordered_field_list:
    #         if field not in self.data_frame:
    #             raise KeyError('{} field missing from DataFrame'.format(field))
    #     self.data_frame = self.data_frame[ordered_field_list]

    def drop_field(self, field_to_drop):
        """ Drop a single field.
    
        Args:
            field_to_drop (string): the name of the field to drop

        Raises:
            KeyError: if the requested field wasn't in the DataFrame
        """
        # checks if the field being dropped is in the dataframe
        if field_to_drop not in self.data_frame:
            raise KeyError 

        drop_list = [field_to_drop]

        self.data_frame.drop(drop_list, axis=1, inplace=True)

        log.info("Data Structure Transformation: dropped field {}".format(field_to_drop))


    def drop_fields(self, fields_to_drop):
        """ drop a list of fields.
        Args:
            fields_to_drop (list): the names of the fields to drop
        Raises:
            KeyError: if a requested field wasn't in the DataFrame
        """
         # checks if all fields being dropped are in the DataFrame
        if not all(field in self.data_frame for field in fields_to_drop):
            raise KeyError

        self.data_frame.drop(fields_to_drop, axis=1, inplace=True)

        log.info("Data Structure Transformation: dropped fields {}".format(','.join(fields_to_drop)))

    # TODO: change to accept a single field or a list & rename function
    # TODO (MW): what's the use case for the 'replace' param? we also have 'add field'
    def rename_field_name(self, initial_field_name, final_field_name, replace=True):
        """ Rename a field.

        Args: 
            initial_field_name (str): the name of the field to be renamed
            final_field_name (str): what the field should be renamed to.
            replace (bool): Ireplace the initial_field_name from the DataFrame

        Raises:
            KeyError: if initial_field_name is not in DataFrame
        """
        if initial_field_name not in self.data_frame:
            raise KeyError
        
        if replace:
            self.data_frame.rename(columns={initial_field_name: final_field_name}, inplace=True)
        else:
            # introduce a new column
            self.data_frame[final_field_name] = self.data_frame[initial_field_name]

        log.info("Data Structure Transformation: renamed field from {} to {}".format(initial_field_name, final_field_name))


    def format_date_field(self, field_name, inital_date_format, final_date_format):
        """ Reformat date values. Any value that does not conform to inital_format will be returned unmodified.

        Notes:
          - For more details on acceptable datetime formatting see:
            https://docs.python.org/2/library/datetime.html#strftime-and-strptime-behavior
          - TODO: investigate. This method my be to inflexible, in the case the 
            the field had mutiple formats of unexpected types

        Args:
            field_name (str): expectefield to be sting values in intital_format, or datatime object already.
            inital_format (str): valid datetime format code
            final_format (str): valid datetime format code

        Raises:
            KeyError: if field_name is not in DataFrame
            ValueError: if a field value does not match the inital_format
        """
        if field_name not in self.data_frame:
            raise KeyError

        self.data_frame[field_name] = self.data_frame[field_name].apply(
            lambda x: reformat_date_value(x, inital_date_format, final_date_format))

        log.info("Data Value Transformation: standarized date format for field {}".format(field_name))

    def constrain_field_value_length(self, field_name, constraint_length, slice_direction):
        """ Constrain field values to a desired length.

        Notes: 
          - If constraint_length is larger than field value, the value will be 
            returned as a string of the same input length, does not 'pad' values.
          - Method modifies all values in field_name to be string.
          - TODO: a more atomic method might be appropriate, constrain_value_length

        Args:
            field_name (str):
            constraint_length (int):
            slice_direction (str): valid options are 'left' or 'right'

        Raises:
            ValueError: if slice_direction argumnet value is not valid
            ValueError: if constraint_length < 0
            KeyError: if field_name is is not in DataFrame 

        """
        if field_name not in self.data_frame:
            raise KeyError

        valid_slice_directions = ['left', 'right']
        if slice_direction not in valid_slice_directions:
            raise ValueError
        if constraint_length < 0:
            raise ValueError

        if slice_direction == 'left':
            # 'hvtn' with constraint_length=2 >>> 'hv'
            self.data_frame[field_name] = self.data_frame[field_name].apply(
                lambda x: str(x)[:constraint_length])
        if slice_direction == 'right':
            # 'hvtn' with constraint_length=2 >>> 'tn'
            self.data_frame[field_name] = self.data_frame[field_name].apply(
                lambda x: str(x)[-constraint_length:])

        log.info("Data Value Transformation: field length constrained for field {} to length {}".format(field_name, constraint_length))


    # TODO change this to take either a single field or a list & rename:
    def add_new_field(self, field_name, field_value=np.nan):
        """ Add a new field, will add new field to end of DF.

        Args:
            field_name (str): name of the field to be added 
            field_value: optional, default to np.nan

        Raises:
            ValueError: if field_name already exsists in the DataFrame
        """
        if field_name in self.data_frame:
            raise ValueError

        self.data_frame.loc[:, field_name] = field_value

        log.info("Data Structure Transformation: new field {} added".format(field_name))


    def replace_unicode_value_in_field(self, field_name, unicode_value, replacement_value):
        """
        Args:
            field_name (str): name of the field to have unicode values replaced
            unicode_value (str): escaped unicode code ie '\xd0'
            replacement_value (str): the string value meant to replace the unicode value

        Raises:
            KeyError: if field_name is not in DataFrame.
        """
        if field_name not in self.data_frame:
            raise KeyError
        
        self.data_frame[field_name] = self.data_frame.apply(lambda row: re.sub(unicode_value, replacement_value, row[field_name]), axis=1)

        log.info("Data Structure Transformation: unicode character replaced for field {}".format(field_name))

    def set_new_values_for_field(self, field_name, new_value):
        """ Natalie Demo"""
        self.data_frame[field_name] = new_value

    def down_case_field_names(self, field_names=None):
        """ Down case field names in a DataFrame. 
        
        Args:
            field_name (str or list): Optional. The field name(s) to down case.
                If no value is passed, all DataFrame field names will be down cased.

        Raises:
            KeyError: if field_names is not in DataFrame.
            ValueError: if field_names is not a string or a list
        """
        if not field_names:
            # down case all field names
            all_fields = self.data_frame.columns.values.tolist()
            for field in all_fields:
                self.data_frame.rename(columns={field: field.lower()}, inplace=True)

        elif isinstance(field_names, str):
            if field_names not in self.data_frame:
                raise KeyError('field {} missing from DataFrame'.format(field_names))
            self.data_frame.rename(columns={field_names: field_names.lower()}, inplace=True)

        elif isinstance(field_names, list):
            for field in field_names:
                if field not in self.data_frame:
                    raise KeyError('field {} missing from DataFrame'.format(field))
                self.data_frame.rename(columns={field: field.lower()}, inplace=True)

        else:
            err_msg = 'Expect field_names parameter to be list or string'
            log.error(err_msg)
            raise ValueError(err_msg)

        # TODO improve log message
        log.info("Data Structure Transformation: field name lowercased")

    def fill_blank_field_values_using_values_from_another_field(self, field_name, 
        other_field_name):
        """ Fill in blank values for a particular field using values from another field.
        
        Works on both both np.nan and blank string missing values

        Args:
            field_name (str): name of field that contains blanks
            other_field_name (str): name of field whose values will be used to 
                fill blanks values in field_name

        Raises:
            KeyError: if field_name is not in DataFrame.
            KeyError: if other_field_name is not in DataFrame.
        """

        err_msg = 'field {} expected in DataFrame'
        if field_name not in self.data_frame:
            raise KeyError(err_msg.format(field_name))
        if other_field_name not in self.data_frame:
            raise KeyError(err_msg.format(other_field_name))

        # handle np.nan blank values
        self.data_frame[field_name].fillna(self.data_frame[other_field_name], inplace=True)
        log.info("Data Structure Transformation: blank values in field {} filled using values from field {}".format(field_name, other_field_name))

        # handle empty string blank values
        self.data_frame[field_name] = self.data_frame.apply(
            lambda row: row[other_field_name] if row[field_name] == '' else row[field_name], axis=1)

    def replace_field_values(self, field_name, value_replacements, 
        case_sensative=False, ignore_punctuation_and_spaces=False, match_if_contains=False):
        """ Replace specific values in a given field.

        Args:
            field_name (str): name of the field to have its values replaced 
                using value_replacements.
            value_replacements (dict): a mapping of the inital to final values.
                ex: {initial_value: final_value}
            case_sensative (bool): Optional. Require inital_value in 
                value_replacements to case match the value in field_name.
                Default is False, the inital_value will be matched to the values 
                in field_name in a case-insensative manner.
            ignore_punctuation_and_spaces (bool): Optional. if true,
                test string matches without regard to spaces or punctuation

        Raises:
            KeyError: if field_name is not in DataFrame.
        """
        if field_name not in self.data_frame:
            raise KeyError('field {} expected in DataFrame'.format(field_name))

        punctuation_and_spaces_string = r'[^a-zA-Z0-9]'


        # TODO!!!!
        # stop replacing after the first replacement
        for from_string, to_string in value_replacements.iteritems():
            df_value_to_test = ''
            replacement_value_to_test = ''



            for index, row in self.data_frame.iterrows():

                df_value_to_test = row[field_name]
                replacement_value_to_test = from_string
                
                if not case_sensative:
                    df_value_to_test = df_value_to_test.upper()
                    replacement_value_to_test = replacement_value_to_test.upper()
                

                if ignore_punctuation_and_spaces:
                    # disregard punctuation and strings in the match
                    df_value_to_test = re.sub(punctuation_and_spaces_string, '', df_value_to_test)
                    replacement_value_to_test = re.sub(punctuation_and_spaces_string, '', replacement_value_to_test)

                # we do one of two tests:
                # either, check if the test string is a substring of the dataframe value,
                # or,
                # check if the test string is the data frame value
                if match_if_contains:
                    if replacement_value_to_test in df_value_to_test:
                        self.data_frame[field_name][index] = to_string
                elif df_value_to_test == replacement_value_to_test:
                    self.data_frame[field_name][index] = to_string



            # if case_sensative:
            #     self.data_frame[field_name] = self.data_frame[field_name].apply(
            #         lambda x: value if x==key else x)
            # else:
            #     self.data_frame[field_name] = self.data_frame[field_name].apply(
            #         lambda x: value if x.upper()==key.upper() else x)

        # TODO better logging message
        log.info("Data Structure Transformation: values in field {} standardized using values from acceptable value list".format(field_name))

#-----------------------------------------------------------------------------#
# DEPRICATED METHODS
# Please do not resue these methods in new pipeline set up. The plan is for these
# methods to be refactored and the calling scripts updated.

    # TODO: see replacement method: down_case_field_names()
    def down_case_field_name(self, field_name):
        """ 
        Args:
            field_name (str): name of the field to down case

        Raises:
            KeyError: if field_name is not in DataFrame.
        """
        if field_name not in self.data_frame:
            raise KeyError

        self.data_frame.rename(columns={field_name: field_name.lower()}, inplace=True)

#-----------------------------------------------------------------------------#
# HELPER FUNCTIONS
# TODO JT: move to io_utils and update imports/calls
def reformat_date_value(value, inital_date_format, final_date_format):
    """ Reformat datetime values and string values that conform to inital_format.

    Args:
        value (str): value to cast to datetime
        inital_date_format (str): valid datetime format code
        final_date_format (str): valid datetime format code

    Returns:
        If input is string and conforms to date_foramt or is datetime object, returns string value in final_date_format. 
        Otherwise the value is returned unmodified.
    """

    # if value is datetime, reformat and return as string
    if isinstance(value, datetime.datetime):
        reformatted_value = value.strftime(final_date_format)
        return reformatted_value

    # if value is string and confirms to inital_date_format, reformat and retrun as string
    if isinstance(value, str):
        try:
            datetime_value = datetime.datetime.strptime(value, inital_date_format)
        except ValueError:
            return value
        reformatted_string_value = datetime_value.strftime(final_date_format)
        return reformatted_string_value

    # return value unmodified 
    return value

#-----------------------------------------------------------------------------#

if __name__ == '__main__':
    pass
