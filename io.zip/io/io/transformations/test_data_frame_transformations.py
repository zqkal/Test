#!/usr/local/apps/python/python-controlled/bin/python -tt
# -*- coding: utf-8 -*-

""" Module to hold DataFrameTransformations tests """

# import io_utils
import datetime
import numpy as np
import pandas as pd
from pandas.util.testing import assert_frame_equal # <-- for testing dataframes
import pytest
import re

from data_frame_transformations import DataFrameTransformations

#-----------------------------------------------------------------------------#
# HELPER FUNCTIONS
# TODO JT: move to io_utils and update imports/calls
def reformat_date_value(value, inital_date_format, final_date_format):
    """ Reformat datetime values and string values that conform to inital_format.

    Args:
        value (str): value to cast to datetime
        inital_date_format (str): valid datetime format code
        final_date_format (str): valid datetime format code

    Returns:
        If input is string and conforms to date_foramt or is datetime object, returns string value in final_date_format. 
        Otherwise the value is returned unmodified.
    """

    # if value is datetime, reformat and return as string
    if isinstance(value, datetime.datetime):
        reformatted_value = value.strftime(final_date_format)
        return reformatted_value

    # if value is string and confirms to inital_date_format, reformat and retrun as string
    if isinstance(value, str):
        try:
            datetime_value = datetime.datetime.strptime(value, inital_date_format)
        except ValueError:
            return value
        reformatted_string_value = datetime_value.strftime(final_date_format)
        return reformatted_string_value

    # return value unmodified 
    return value

#-----------------------------------------------------------------------------#

class TestReplaceFieldValues:

    def test_replace_values_case_sensitive(self):
        df = DataFrameTransformations(pd.DataFrame({'field': ['A_b', 'a_b']}))
        df.replace_field_values(
            'field', 
            {'A_b': 'replacement'}, 
            case_sensative=True)
        expected_df = pd.DataFrame({'field': ['replacement', 'a_b']})
        assert_frame_equal(df.data_frame, expected_df)

    def test_replace_values_case_insensitive(self):
        df = DataFrameTransformations(pd.DataFrame({'field': ['A_b', 'a_b']}))
        df.replace_field_values(
            'field', 
            {'A_b': 'replacement'})
        expected_df = pd.DataFrame({'field': ['replacement', 'replacement']})
        assert_frame_equal(df.data_frame, expected_df)


    def test_replace_values_ignore_punctuation_and_spaces_case_sensitive(self):
        df = pd.DataFrame({'field': [r'#$A_^b', r'#$a_^b']})
        transformer = DataFrameTransformations(df)
        transformer.replace_field_values('field', 
            {r'A_b': '-- a _ b ---'}, case_sensative=True, ignore_punctuation_and_spaces=True)
        expected_df = pd.DataFrame({'field': ['-- a _ b ---', r'#$a_^b']})
        assert_frame_equal(df, expected_df)


    def test_replace_values_ignore_punctuation_and_spaces_case_insensitive(self):
        df = pd.DataFrame({'field': [r'#$A_^b', r'@@*$a_^))b']})
        transformer = DataFrameTransformations(df)
        transformer.replace_field_values(
            'field', 
            {r'#$A_^b': '-- a _ b ---'}, 
            case_sensative=False,
            ignore_punctuation_and_spaces=True)
        expected_df = pd.DataFrame({'field': ['-- a _ b ---', '-- a _ b ---']})
        assert_frame_equal(df, expected_df)


   

    def test_raise_key_error_if_field_missing(self):
        df = DataFrameTransformations(pd.DataFrame())
        with pytest.raises(KeyError):
            df.replace_field_values('missing_field', {})

class TestFillBlankFieldValuesUsingValuesFromAnotherField:
    
    def test_adds_field_values(self):
        df = pd.DataFrame({
            'field': ['v1', np.nan, 'v3', '', np.nan],
            'other_field': ['o1', 'fill_value1', 'o2','fill_value2', np.nan],
            })
        df = DataFrameTransformations(df)
        df.fill_blank_field_values_using_values_from_another_field(
            'field', 'other_field')
        expected_df = pd.DataFrame({
            'field': ['v1', 'fill_value1', 'v3', 'fill_value2', np.nan],
            'other_field': ['o1', 'fill_value1', 'o2','fill_value2', np.nan],
            })
        assert_frame_equal(df.data_frame, expected_df)

    def test_raise_key_error_if_field_missing(self):
        df = DataFrameTransformations(pd.DataFrame(columns=['other_field']))
        with pytest.raises(KeyError):
            df.fill_blank_field_values_using_values_from_another_field(
                'field', 'other_field')

    def test_raise_key_error_if_other_field_missing(self):
        df = DataFrameTransformations(pd.DataFrame(columns=['field']))
        with pytest.raises(KeyError):
            df.fill_blank_field_values_using_values_from_another_field(
                'field', 'other_field')


class TestDownCaseFieldNames:

    def test_down_case_single_field(self):
        df = DataFrameTransformations(pd.DataFrame(
            columns=['LOWER_CASE', 'OTHER']))
        df.down_case_field_names('LOWER_CASE')
        expected_df = pd.DataFrame(columns=['lower_case', 'OTHER'])
        assert_frame_equal(df.data_frame, expected_df)

    def test_down_case_list_of_fields(self):
        df = DataFrameTransformations(pd.DataFrame(
            columns=['LOWER_CASE', 'OTHER', 'LOWER_CASE2']))
        df.down_case_field_names(['LOWER_CASE', 'LOWER_CASE2'])
        expected_df = pd.DataFrame(
            columns=['lower_case', 'OTHER', 'lower_case2'])
        assert_frame_equal(df.data_frame, expected_df)

    def test_down_case_all_fields(self):
        df = DataFrameTransformations(pd.DataFrame(
            columns=['LOWER_CASE', 'OTHER']))
        df.down_case_field_names()
        expected_df = pd.DataFrame(columns=['lower_case', 'other'])
        assert_frame_equal(df.data_frame, expected_df)

    def test_raise_key_error_for_missing_field(self):
        df = DataFrameTransformations(pd.DataFrame())
        with pytest.raises(KeyError):
            df.down_case_field_names(field_names='nonexistent_field_name')

    def test_raise_key_error_for_missing_field_from_list(self):
        df = DataFrameTransformations(pd.DataFrame())
        with pytest.raises(KeyError):
            df.down_case_field_names(field_names=['nonexistent_field_name'])

    def test_raise_value_error_for_unexpected_parameter_type(self):
        df = DataFrameTransformations(pd.DataFrame())
        with pytest.raises(ValueError):
            df.down_case_field_names(field_names=2)


class TestReformatDateValue:

    def test_datetime_input(self):
        inital_date_format = '%m/%d/%Y'
        final_date_format = '%Y/%m/%d'
        value = datetime.datetime.strptime('01/11/1987', inital_date_format)
        output = reformat_date_value(value, inital_date_format, final_date_format)
        assert output == '1987/01/11'

    def test_int_input(self):
        inital_date_format = '%m/%d/%Y'
        final_date_format = '%Y/%m/%d'
        value = 1234
        output = reformat_date_value(value, inital_date_format, final_date_format)
        assert output == value

    def test_str_input_correct_format(self):
        inital_date_format = '%m/%d/%Y'
        final_date_format = '%Y/%m/%d'
        value = '01/11/1987'
        output = reformat_date_value(value, inital_date_format, final_date_format)
        assert output == '1987/01/11'

    def test_str_input_incorrect_format(self):
        inital_date_format = '%Y/%m/%d'
        final_date_format = '%Y/%m/%d'
        value = '01/11/1987'
        output = reformat_date_value(value, inital_date_format, final_date_format)
        assert output == value


class TestRenameFieldName:
        
    def test_add_new_field_with_replace_true(self):
        df = DataFrameTransformations(pd.DataFrame({'network': ['hvtn']}))
        df.rename_field_name('network', 'new_field_name')
        expected_df = pd.DataFrame({'new_field_name': ['hvtn']})
        assert_frame_equal(df.data_frame, expected_df)

    def test_add_new_field_with_replace_false(self):
        df = DataFrameTransformations(pd.DataFrame({'network': ['hvtn']}))
        df.rename_field_name('network', 'new_field_name', replace=False)
        expected_df = pd.DataFrame({'network': ['hvtn'], 'new_field_name': ['hvtn']})
        assert_frame_equal(df.data_frame, expected_df)

    def test_raise_key_error_for_missing_field(self):
        df = DataFrameTransformations(pd.DataFrame())
        with pytest.raises(KeyError):
            df.rename_field_name('nonexistent_field_name', 'new_field_name')


class TestFormatDateField:
    # bulk of testing done for atomic method: reformat_date_value
    def test_format_date_field(self):
        df = DataFrameTransformations(pd.DataFrame({
            'drawdt': ['02/22/2018', '12DEC2018', 
                datetime.datetime.strptime('02/24/2018', '%m/%d/%Y')]}))
        df.format_date_field('drawdt', '%m/%d/%Y', '%Y-%m-%d')
        expected_df = pd.DataFrame({'drawdt': ['2018-02-22', '12DEC2018', '2018-02-24']})
        assert_frame_equal(df.data_frame, expected_df)

    def test_raise_key_error_for_missing_field(self):
        df = DataFrameTransformations(pd.DataFrame())
        with pytest.raises(KeyError):
            df.format_date_field('drawdt', '%m/%d/%Y', '%Y-%m-%d')


class TestConstrainFieldValueLength:

    def test_left_slice(self):
        df = DataFrameTransformations(pd.DataFrame({'network': ['hvtn']}))
        df.constrain_field_value_length('network', 1, 'left')
        expected_df = pd.DataFrame({'network': ['h']})
        assert_frame_equal(df.data_frame, expected_df)

    def test_right_slice(self):
        df = DataFrameTransformations(pd.DataFrame({'network': ['hvtn']}))
        df.constrain_field_value_length('network', 1, 'right')
        expected_df = pd.DataFrame({'network': ['n']})
        assert_frame_equal(df.data_frame, expected_df)

    def test_constaint_length_larger_than_field_value(self):
        df = DataFrameTransformations(pd.DataFrame({'network': ['hvtn']}))
        df.constrain_field_value_length('network', 5, 'right')
        expected_df = pd.DataFrame({'network': ['hvtn']})
        assert_frame_equal(df.data_frame, expected_df)

    def test_raise_key_error_for_missing_field(self):
        df = DataFrameTransformations(pd.DataFrame())
        with pytest.raises(KeyError):
            df.constrain_field_value_length('nonexistent_field_name', 5, 'left')

    def test_raise_value_error_for_invalid_slice_direction_parameter(self):
        df = DataFrameTransformations(pd.DataFrame({'network': ['hvtn']}))
        with pytest.raises(ValueError):
            df.constrain_field_value_length('network', 2, 'invalid_argumnent_value')

    def test_raise_value_error_for_constariant_length_smaller_than_zero(self):
        df = DataFrameTransformations(pd.DataFrame({'network': ['hvtn']}))
        with pytest.raises(ValueError):
            df.constrain_field_value_length('network', -1, 'left')


class TestDownCaseFieldName:

    def test_down_case_field_name(self):
        df = DataFrameTransformations(pd.DataFrame({'NetWork': ['hvtn']}))
        df.down_case_field_name('NetWork')
        expected_df = pd.DataFrame({'network': ['hvtn']})
        assert_frame_equal(df.data_frame, expected_df)

    def test_raise_key_error_for_missing_field(self):
        df = DataFrameTransformations(pd.DataFrame())
        with pytest.raises(KeyError):
            df.down_case_field_name('nonexistent_field_name')


class TestAddNewField:

    def test_add_new_field_defult_value(self):
        df = DataFrameTransformations(pd.DataFrame({'network': ['hvtn']}))
        df.add_new_field('protocol')
        expected_df = pd.DataFrame({'network': ['hvtn'], 'protocol': [np.nan]})
        assert_frame_equal(df.data_frame, expected_df)

    def test_add_new_field_custom_value(self):
        df = DataFrameTransformations(pd.DataFrame({'network': ['hvtn']}))
        df.add_new_field('protocol', '116')
        expected_df = pd.DataFrame({'network': ['hvtn'], 'protocol': ['116']})
        assert_frame_equal(df.data_frame, expected_df)

    def test_raise_value_error_if_field_already_in_dataframe(self):
        df = DataFrameTransformations(pd.DataFrame({'network': ['hvtn']}))
        with pytest.raises(ValueError):
            df.add_new_field('network')

class TestReplaceUnicodeValueInField:

    def test_replace_unicode(self):
        # TODO This test is failing!!
        df = DataFrameTransformations(pd.DataFrame({'network': [u'hv\u0394n']}))
        df.replace_unicode_value_in_field('network', u'\u0394', 'D')
        expected_df = pd.DataFrame({'network': ['hvDn']})
        assert_frame_equal(df.data_frame, expected_df)

    def test_raise_key_error_for_missing_field(self):
        df = DataFrameTransformations(pd.DataFrame())
        with pytest.raises(KeyError):
            df.replace_unicode_value_in_field('nonexistent_field_name', u'\u0394', 'D')

class TestDropField:

    def test_field_is_dropped(self):
        df = pd.DataFrame({'network': ['hvtn']})
        transformer = DataFrameTransformations(df)
        transformer.drop_field('network')
        assert len(df.columns) == 0

    def test_key_error_if_no_column_present(self):
        df = pd.DataFrame({'network': ['hvtn']})
        transformer = DataFrameTransformations(df)
        with pytest.raises(KeyError):
            transformer.drop_field('fizzbuzz')

class TestDropFields:

    def test_single_field_is_dropped(self):
        df = pd.DataFrame({'network': ['hvtn'], 'protocol': ['116']})
        transformer = DataFrameTransformations(df)
        transformer.drop_fields(['network'])
        assert len(df.columns) == 1


    def test_mulltiple_fields_are_dropped(self):
        df = pd.DataFrame({'network': ['hvtn'], 'protocol': ['116']})
        transformer = DataFrameTransformations(df)
        transformer.drop_fields(['network', 'protocol'])
        assert len(df.columns) == 0

    def test_key_error_if_no_column_present(self):
        df = pd.DataFrame({'network': ['hvtn'], 'protocol': ['116']})
        transformer = DataFrameTransformations(df)
        with pytest.raises(KeyError):
            transformer.drop_fields(['network', 'fizzbuzz'])




#-----------------------------------------------------------------------------#

if __name__ == '__main__':
    pass
