

# wrapping pretty basic functionality so that things only need to be implemented,
# and tested, in one place



# what is the file extention?



# get file size (bytes) - simple wrapper

