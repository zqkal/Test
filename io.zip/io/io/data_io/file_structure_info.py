# get tsv/csv header as list

# get number of lines