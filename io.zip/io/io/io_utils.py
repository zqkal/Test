#!/usr/local/apps/python/python-controlled/bin/python -tt

# shared global helper functions

# ideally, this file should not depend on anything else in this project.
# It's meant to be the lowest level in the file dependency graph.

# def some_global_helper():
#	pass
