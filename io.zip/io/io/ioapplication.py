#!/usr/local/apps/python/python-controlled/bin/python -tt
""" TODO (NT): Header Comment """

import argparse
import sys

import imports
from pipelines import Pipelines

#-----------------------------------------------------------------------------#

def get_args():
    """ Parse command line arguments """
    argparser = argparse.ArgumentParser(
        description='process SCHARP client laboratory data',
        epilog="version DEV, SCHARP Lab Data Ops Programming team")

    argparser.add_argument(
        'network',
        type=str,
        help="""The SCHARP client network that this script is being invoked for.""")

    argparser.add_argument(
        'lab_id',
        type=str,
        help="""The SCHARP client laboratory's code; usually two letters.""")

    argparser.add_argument(
        'protocol',
        type=str,
        help="""The experiemental protocol.""")

    argparser.add_argument(
        'assay',
        type=str,
        help="""The assay name that this script is being invoked for. network, protocol, and assay must all be specified to uniquely identify a processing pipeline.""")

    argparser.add_argument(
        'input_data_path',
        type=str, 
        help="""Filesytem path to the data file to process.""")
        # TODO: this arg will depend on what file structre schem we create for this application
        # help="""Filesytem path to the directory containing data to process.""")

    argparser.add_argument(
        'output_data_path',
        type=str, 
        help="""Filesystem path to the directory to be used for outputs.""")

    # TODO: "list" command
    # -- list by network
    # -- list by network, protocol
    # -- list assays
    # -- list assays for network

    args = argparser.parse_args()
    return args

# TODO MW or NT: figure out how to give argparse an arg on these
def check_args(args):
    if ('' in [args.network, args.protocol, args.assay, args.lab_id]):
        print 'network, protocol, and assay must all be specified to uniquely identify a processing pipeline'
        logging.error('network, protocol, and assay must all be specified to uniquely identify a processing pipeline')
        sys.exit(-1)

    # TODO: check i/o paths

def main():
    import logging
    logging.basicConfig(level=logging.DEBUG, format='%(asctime)s\t[%(levelname)s]\t%(message)s', datefmt='%d-%b-%y %H:%M:%S')
    logging.debug('parsing commandline arguments')

    # get commandline args
    args = get_args()
    check_args(args) # TODO: arparse has built in functionality for arg checking.

    pipeline_factory = Pipelines()

    # TODO: use a dictionary and a pipeline factory

    pipeline = pipeline_factory.get_pipeline(args.network, args.protocol, args.assay, args.lab_id)
    if pipeline == None:
        logging.error("unable to match requested pipeline")
        sys.exit(-1)

    # TODO: set up for LDXNAB001, need to generalize
    pipeline.setup(args.input_data_path, args.output_data_path)

    pipeline.run()

#-----------------------------------------------------------------------------#

if __name__ == '__main__':
    main()

    
