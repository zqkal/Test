#!/usr/local/apps/python/python-controlled/bin/python -tt

# does file exist?

# check file extension

# is file larger than a minimum size?

# does the filename match a regex pattern?
