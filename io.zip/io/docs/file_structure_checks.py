#!/usr/local/apps/python/python-controlled/bin/python -tt

# to be implemented without pandas:

# does header match expected header list?

# consistent number of fields per row?

# number of lines?
